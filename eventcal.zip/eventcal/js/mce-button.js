/*------------------------------------------------------------------

File : TinyMCE js
Version: 1.0
Date Created: 15/07/2018
Author: IGlyphic
Licence: Codecanyon Licence 

-------------------------------------------------------------------*/
	(function() {
	    tinymce.PluginManager.add('eventcal', function( editor, url ) {
	        var shortcode_tag = 'eventcal';

		    editor.addButton('eventcal', {
		    	image: eventcaladmindata.imagesurl + 'icon.png',
		    	tooltip: 'Insert EventCal Shortcode',
		    	onclick: function(){
		    		tb_show('EventCal', eventcaladmindata.ajaxurl+'?action=evecalSCForm&nonce='+eventcaladmindata.nonce);
		    	}
		    });
	    });
	})();