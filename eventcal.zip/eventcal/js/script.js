/*------------------------------------------------------------------

File : Main js file
Version: 1.0
Date Created: 15/07/2018
Author: iGlyphic
Licence: Codecanyon Licence 

-------------------------------------------------------------------*/


jQuery(document).ready(function() {
    "use strict";

    var sevClose = jQuery('.smart-event-close');
    var sevOpen = jQuery('.eventcal-open');
    var sevMainModal = jQuery('.smart-event-overlay');
    var sevBodyClass = 'smart-event-overlay-open';
    var body = jQuery('body');

    var _sevOpen = function(){
        body.addClass(sevBodyClass);
        sevMainModal.addClass('open');
    }
    var _sevClose = function(){
        body.removeClass(sevBodyClass);
        sevMainModal.removeClass('open');
        resetcontents();
    }
    var resetcontents = function(){
        _resettitledate();
        _resetcontainer();
        _resetmap();
        _resetsidebar();
        _resetimgcontainer();
    }
    var requestcontents = function(dataid){
        _reqtitledate(dataid);
        _reqcontent(dataid);
        _reqheaderimg(dataid);
        _reqsidebar(dataid);
    }

    /*
     ** Requests
     */
    var _reqheaderimg = function( id ){
        _ajaxrequest('requestHeaderImg', id);
    }
    var _reqtitledate = function( id ){
        _ajaxrequest('requestTitleDate', id);
    }
    var _reqcontent = function( id ){
        _ajaxrequest('requestContent', id);
    }
    var _reqsidebar = function( id ){
        _ajaxrequest('requestSidebar', id);
    }

    /*
     ** Set Fields
    */
    var _setheaderimg = function(response){
        var imgcontainer = jQuery('.smart-event-single-featured-image');

        if(response.imageurl){
            imgcontainer.fadeTo('slow', 0.5, function(){
                jQuery(this).css('background-image', 'url('+ response.imageurl +')');
            }).fadeTo('slow', 1);
        }

        jQuery('.spinner').fadeOut();
    }
    var _settitledate = function(response){
        var titlecontainer = jQuery('.smart-event-single-title');
        if(response.title){
            titlecontainer.fadeTo('slow', 0.5, function(){
                jQuery(this).append(response.title);
            }).fadeTo('slow', 1);
        }
    }
    var _setcontent = function(response){
        var contentcontainer = jQuery('.smart-event-single-tabbed-info');
        if(response.content){
            contentcontainer.fadeTo('slow', 0.5, function(){
                jQuery(this).append(response.content);
            }).fadeTo('slow', 1);
            jQuery('.spinner-container').fadeOut();
        }

    }
    var _setmap = function(response){
        if(response.map){
            _geteventmap(response.map);
        }
    }
    var _setsidebar = function(response){
        var sidebarcontainer = jQuery('.smart-event-side-info');
        sidebarcontainer.fadeTo('slow', 0.5, function(){
            jQuery(this).append(response.sidebar);
        }).fadeTo('slow', 1);

    }

    /*
    ** Reset Fields
    */
    var _resetimgcontainer = function(){
        var imgcontainer = jQuery('.smart-event-single-featured-image');
        imgcontainer.css('background-image', '');
        jQuery('.spinner').fadeIn();

    }
    var _resettitledate = function(){
        var titlecontainer = jQuery('.smart-event-single-title');
        titlecontainer.html('');
    }
    var _resetcontainer = function(){
        var contentcontainer = jQuery('.smart-event-single-tabbed-info');
        contentcontainer.html('');
        jQuery('.spinner-container').fadeIn();

    }
    var _resetsidebar = function(){
        var sidebarcontainer = jQuery('.smart-event-side-info');
        sidebarcontainer.html('');
    }
    var _resetmap = function(){
        var mapcontainer = jQuery('#event-map');
        mapcontainer.html('');
    }


    // Rendering Google maps
    var _geteventmap = function( mapdata ){
        //Show google map
        var myLatlng = new google.maps.LatLng( mapdata[0], mapdata[1] );
        var mapOptions = {
            zoom: 15,
            center: myLatlng,
            styles:
            [{"featureType":"landscape","elementType":"geometry","stylers":[{"saturation":"-100"}]},{"featureType":"landscape.man_made","elementType":"geometry.fill","stylers":[{"color":"#e9e5dc"}]},{"featureType":"poi","elementType":"labels","stylers":[{"visibility":"off"}]},{"featureType":"poi","elementType":"labels.text.stroke","stylers":[{"visibility":"off"}]},{"featureType":"road","elementType":"labels.text","stylers":[{"color":"#545454"}]},{"featureType":"road","elementType":"labels.text.stroke","stylers":[{"visibility":"off"}]},{"featureType":"road.highway","elementType":"geometry.fill","stylers":[{"saturation":"-87"},{"lightness":"-40"},{"color":"#ffffff"}]},{"featureType":"road.highway","elementType":"geometry.stroke","stylers":[{"visibility":"off"}]},{"featureType":"road.highway.controlled_access","elementType":"geometry.fill","stylers":[{"color":"#f0f0f0"},{"saturation":"-22"},{"lightness":"-16"}]},{"featureType":"road.highway.controlled_access","elementType":"geometry.stroke","stylers":[{"visibility":"off"}]},{"featureType":"road.highway.controlled_access","elementType":"labels.icon","stylers":[{"visibility":"on"}]},{"featureType":"road.arterial","elementType":"geometry.stroke","stylers":[{"visibility":"off"}]},{"featureType":"road.local","elementType":"geometry.stroke","stylers":[{"visibility":"off"}]},{"featureType":"water","elementType":"geometry.fill","stylers":[{"saturation":"-52"},{"hue":"#00e4ff"},{"lightness":"-16"}]}]
        }
        var map = new google.maps.Map(document.getElementById('event-map'), mapOptions);
        var marker = new google.maps.Marker({
            position: myLatlng,
            map: map,
            title : 'Click To Open Info',
            icon: eventcaldata.imagesurl + 'marker.png',
        });


        //Redraw and center map
        google.maps.event.addListenerOnce(map, 'idle', function() {
            google.maps.event.trigger(map, 'resize');
            var infowindowcontent = '<h6>'+ mapdata[4].day +' '+ mapdata[4].month +'</h6><p>'+ mapdata[3] +'</p>';
            // Recenter the map now that it's been redrawn
            var reCenter = new google.maps.LatLng();
            map.setCenter(reCenter);
            var infowindow = new google.maps.InfoWindow({
                content: infowindowcontent
            });
            marker.addListener('click', function(){
                infowindow.open(map, marker);
            });
        });
    }
    /*
    ** Ajax Requests
    */
    var _ajaxrequest = function( action, id ){

        var mapcontainer = jQuery('#event-map');
        jQuery.ajax({
            type : 'post',
            url: eventcaldata.ajaxurl,
            data:{
                action : action,
                id : id,
                nonce : eventcaldata.nonce,
            },
            beforeSend : function(){},
            success: function(response){
                if(response.title){
                    _settitledate(response);
                }
                else if (response.content) {
                    _setcontent(response);
                    _setmap(response);
                }
                else if (response.sidebar){
                    _setsidebar(response);
                }
                else if (response.imageurl){
                    _setheaderimg(response);
                }
            }
        });
    }

    sevOpen.on('click', function(event){
        event.preventDefault();
        var dataid = jQuery(this).data('id');
        event.preventDefault();
        _sevClose();
        _sevOpen();
        requestcontents(dataid);
    });

    sevClose.on('click', function(event){
        event.preventDefault();
        _sevClose();
    });

    jQuery(document).on('ready', function(){
        if(jQuery('.evecal-individual-single').length == 1){
            requestcontents(singlepostid);
        }
    });

    jQuery(document).keyup(function(e) {
        if (e.keyCode == 27) {
            _sevClose();
        }
    });

    var _getweekevents = function(week, year){
        var table = jQuery('.evecal-weekly-view');
        var container = jQuery('.evecal-weekly-post-container');
        jQuery.ajax({
            type: 'post',
            url: eventcaldata.ajaxurl,
            data:{
                action: 'evecal_weekly_posts',
                week : week,
                year: year,
                nonce : eventcaldata.nonce
            },
            beforeSend: function(){
                container.html('<span class="spinner"></span>');
            },
            success: function(request){
                table.html(request.table).fadeIn();

                container.html(request.message).fadeIn();
            },
        });
    }

    var _getperdayweekevents = function(date){
        var container = jQuery('.evecal-weekly-post-container');
        jQuery.ajax({
            type: 'post',
            url: eventcaldata.ajaxurl,
            data:{
                action: 'evecal_weekly_day_posts',
                date : date,
                nonce : eventcaldata.nonce
            },
            beforeSend: function(){
                container.html('<span class="spinner"></span>');
            },
            success: function(request){
                container.html(request.message).fadeIn();
            },
        });
    }

    jQuery('.evecal-weekly-view').on('click', '.whole-week', function(e){
        e.preventDefault();
        var week = jQuery(this).data('week');
        var year = jQuery(this).data('year');
        _getweekevents(week, year);
    });

    jQuery('.evecal-weekly-view').on('click', 'td.weekly-date-shuffle', function(e){
        var date = jQuery(this).data('date');
        jQuery('td.weekly-date-shuffle').removeClass('active');
        jQuery(this).addClass('active');
        _getperdayweekevents(date);
    });

    jQuery('#ec-search-key').donetyping(function(){
        _initAjaxSearch();
    });
    jQuery('.ec-ajax-search').on('submit', function(e){
        e.preventDefault();
        _initAjaxSearch();
    });
    jQuery('.ec-dropdown-filter').on('change', function(){
        _initAjaxSearch();
    });
    jQuery('.ec-filter-all').on('change', function(){
        var date = jQuery(this).val();
        jQuery(this).closest('.ec-filter-by-months').find('input[type=radio]').prop('checked', false);
        jQuery(this).prop('checked', true);
        _initAjaxSearch(date);
    });
    jQuery(document).on('change','.ec-filter-months', function(){
        _initAjaxSearch();
    });
    var _initAjaxSearch = function(fixeddate = ''){
        var style = jQuery('.event-contents').data('style');
        var columns = jQuery('.event-contents').data('column');
        if(fixeddate == ''){
            var date = jQuery('#ec_filter_months').val();
        }else{
            var date = fixeddate;
        }

        var searchCriteria = jQuery('.ec-ajax-search').serialize(); 

        if(date !== ''){
            searchCriteria += '&ec-filter-months=' + date;
        }
        searchCriteria = searchCriteria.replace(/&?[^=]+=&|&[^=]+=$/g,'');

        _ajaxEventSearch(searchCriteria, style, columns);
    }

    var _ajaxEventSearch = function(s, style, columns){
        var container = jQuery('.event-contents');
        jQuery.ajax({
            type: 'post',
            url: eventcaldata.ajaxurl,
            data:{
                action: 'evecal_ajax_search',
                query: s,
                style: style,
                columns: columns,
                nonce : eventcaldata.nonce
            },
            beforeSend : function(){
                container.removeClass('waiting').addClass('waiting');
                container.css('opacity', 0).html('<span class="spinner"></span>').fadeTo('normal', 1);
                jQuery('.smart-event-pagination').css('display', 'none');
            },
            success : function(response){
                console.log(response);
                container.css('opacity', 0).html(response.content).fadeTo('normal', 1);
                if(response.showdate !== ""){
                    jQuery('.ec-filter-month-name').html(response.showdate);
                }
                container.removeClass('waiting');
            },

        });
    }

    jQuery(document).on('click', '.ec-month-filter-nextprev', function(e){
        e.preventDefault();

        var monthscont = jQuery('#ec-filter-by-months');
        var year = jQuery(this).data('year');
        _getYearMonths(year, monthscont);
    });
    var _getYearMonths = function(year, monthscont){
        jQuery.ajax({
            type: 'post',
            url: eventcaldata.ajaxurl,
            data:{
                action: 'ec_ajax_get_months',
                year: year,
                nonce: eventcaldata.nonce,
            },
            beforeSend: function(){
                monthscont.css('opacity', 0.4);
            },
            success: function(response){
                console.log(response);
                monthscont.html(response.dom);
                jQuery('.ec-filter-month-name').html(response.year);
                monthscont.css('opacity', 1);
            }
        });
    }
    jQuery(document).on('click', '#eventcal-tab li a', function(e){
        e.preventDefault();
        var target = jQuery(this).attr('href');
        jQuery('#eventcal-tab-content > .tab-pane').removeClass('show active');
        jQuery('#eventcal-tab-content >'+ target).addClass('show active');
        
    });
    jQuery(document).on('click', '#smart-event-day-schedule li a', function(e){
        e.preventDefault();
        var target = jQuery(this).attr('href');
        jQuery('#schedule > .tab-content > .tab-pane').removeClass('show active');
        jQuery('#schedule > .tab-content >'+ target).addClass('show active');
    });
});
;(function($){
    $.fn.extend({
        donetyping: function(callback,timeout){
            timeout = timeout || 500;
            var timeoutReference,
                doneTyping = function(el){
                    if (!timeoutReference) return;
                    timeoutReference = null;
                    callback.call(el);
                };
            return this.each(function(i,el){
                var $el = $(el);
                $el.is(':input') && $el.on('keyup keypress paste',function(e){
                    if (e.type=='keyup' && e.keyCode!=8) return;

                    if (timeoutReference) clearTimeout(timeoutReference);
                    timeoutReference = setTimeout(function(){
                        doneTyping(el);
                    }, timeout);
                }).on('blur',function(){
                    doneTyping(el);
                });
            });
        }
    });
})(jQuery);