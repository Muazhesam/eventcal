/*------------------------------------------------------------------

File : Main js file
Version: 1.0
Date Created: 15/07/2018
Author: iGlyphic
Licence: Codecanyon Licence 

-------------------------------------------------------------------*/


jQuery(document).ready(function() {
    "use strict";
    jQuery(document).on('click','.ec-repeatable-field-clone', function(e){
        e.preventDefault();
        jQuery(this).closest('.ec-repeatable-fields').find('.ec-repeatable-fieldset').last().clone().insertAfter(jQuery('.ec-repeatable-fieldset').last()).find('input').val('');
    });

    jQuery(document).on('click','.fieldset-close', function(e){
        e.preventDefault();
        jQuery(this).closest('.ec-repeatable-fieldset').remove();
    });
    jQuery(document).on('click', '#evecal-sc-submit', function(e){
    	e.preventDefault();
    	var formdata = jQuery(this).closest('form').serializeArray();
        
    	var dataarray = {};
    	jQuery(formdata).each(function(i, field){
    	    dataarray[field.name] = field.value;
    	});

    	var defaultdata = 'columns="' + dataarray['evecal-sc-columns'] + '" style="' + dataarray['evecal-sc-style'] + '" posts_per_page="'+ dataarray['evecal-sc-ppp'] + '" sortby="' + dataarray['evecal-sc-arrangeby'] + '" range="' + dataarray['evecal-sc-range'] + '"';
        if(dataarray['evecal-monthly-view'] == 'on'){
            defaultdata += ' evecal_monthly_view="true"';
        }
        if(dataarray['evecal-sc-filter'] == 'on'){
            defaultdata += ' filters="true"';
        }
        if(dataarray['evecal-sc-pagination'] == 'on'){
            defaultdata += ' pagination="true"';
        }
        var shortcode = '[eventcal '+ defaultdata +']';
        
        tinyMCE.activeEditor.execCommand('mceInsertContent', 0, shortcode);
        tb_remove();
    });
});