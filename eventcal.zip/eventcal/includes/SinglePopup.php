<?php

namespace WPEVENTCAL\includes;

/**
 *
 * Class SingleData
 * This is used for retriving single piece of data for single event posts
 *
 * @package Wordpress
 * @subpackage EventCal
 * @since v1.0
 *
 *
 */
class SinglePopup
{
	private static $instance = null;

	public static function renderSinglePopup(){
		ob_start();
		echo self::ECOverlay();
		echo self::ECOverlay2();
		echo ob_get_clean();
	}
	
	public static function ECOverlay(){
		ob_start();
		echo '<div class="smart-event-overlay">';
		echo '<div class="smart-event-single-total-content">';
		echo '<i class="smart-event-close pe-7s-close"></i>';
		echo '<div class="smart-event-single-hero">';
		echo '<div class="smart-event-single-featured-image" >';
		echo '<span class="spinner"></span>';
		echo '</div>';
		echo '<div class="smart-event-single-title">';
		echo '</div>';
		echo '</div>';
		echo '<div class="smart-event-single-info">';
		echo '<span class="spinner-container"></span>';
		echo '<div class="smart-event-single-tabbed-info">';
		echo '</div>';
		echo '<div class="smart-event-single-event-info">';
		echo '<h5>Event Information</h5>';
		echo '<div class="event-map-container">';          
		echo '<div id="event-map">';
		echo '</div>';
		echo '</div>';
		echo '<div class="smart-event-side-info">';
		echo '</div>';
		echo '</div>';
		echo '</div>';
		echo '</div>';
		echo '</div>';
		echo '</div>';
		return ob_get_clean();
	}
	public static function ECOverlay2(){
		ob_start();
		echo '<div class="smart-event-overlay-2">';
		echo '<div class="smart-event-single-total-content">';
		echo '<i class="smart-event-close pe-7s-close"></i>';
		echo '<div class="smart-event-single-hero">';
		echo '<div class="smart-event-single-featured-image" >';
		echo '<span class="spinner"></span>';
		echo '</div>';
		echo '<div class="smart-event-single-title">';
		echo '</div>';
		echo '</div>';
		echo '<div class="smart-event-single-info">';
		echo '<span class="spinner-container"></span>';
		echo '<div class="smart-event-single-tabbed-info">';
		echo '</div>';
		echo '<div class="smart-event-single-event-info">';
		echo '<h5>Event Information</h5>';
		echo '<div class="event-map-container">';          
		echo '<div id="event-map">';
		echo '</div>';
		echo '</div>';
		echo '<div class="smart-event-side-info">';
		echo '</div>';
		echo '</div>';
		echo '</div>';
		echo '</div>';
		echo '</div>';
		echo '</div>';
		return ob_get_clean();
	}

	public static function bgImage(){
		$response = array();

		if(!check_ajax_referer(WP_EVECAL_SLUG, 'nonce')){
			return '';
		}
		$post_id = $_POST['id'];

		$postdata = new PostData($post_id);
		
		$response['imageurl'] = $postdata->getEventCover();

		wp_send_json( $response );
	}
	public static function dateTitle(){
		$response = array();

		if(!check_ajax_referer(WP_EVECAL_SLUG, 'nonce')){
			return '';
		}

		$post_id = $_POST['id'];

		$postdata = new PostData($post_id);

		ob_start();
		do_action( 'evecal_single_before_title' );
		
		$title = '<h1>' . $postdata->getPostTitle() . '</h1>';
		
		$title = apply_filters( 'evecal_single_title', $title, $post_id );

		echo $title;
		
		do_action( 'evecal_single_after_title' );

	    echo '<div class="smart-event-single-date">';
		echo '<span>' . $postdata->getEventDate()['day'] . '</span>';
		echo '<span>' . $postdata->getEventDate()['month'] . '</span>';
	    echo '</div>';

	    $response['title'] = ob_get_clean();
		wp_send_json( $response );
	}
	public static function requestContent(){
		if(!check_ajax_referer(WP_EVECAL_SLUG, 'nonce')){
			return '';
		}
		$response = array();
		$post_id = $_POST['id'];
		$postdata = new PostData($post_id);

		ob_start();

		$passid = apply_filters( 'evecal_event_id', $post_id );

		do_action( 'evecal_before_content_tabs' );

		echo '<ul class="nav nav-tabs" id="eventcal-tab">';
		do_action( 'evecal_before_nav_tabs' );
		echo '<li class="nav-item">';
		echo '<a class="nav-link active" id="about-tab" data-toggle="tab" href="#about" role="tab" aria-controls="about" aria-selected="true">'. esc_html__('About', WP_EVECAL_SLUG) . '</a>';
		echo '</li>';
		if(!empty($postdata->getSchedule())){
			echo '<li class="nav-item">';
			echo '<a class="nav-link" id="schedule-tab" data-toggle="tab" href="#schedule" role="tab" aria-controls="schedule" aria-selected="false">'. esc_html__('schedule', WP_EVECAL_SLUG) . '</a>';
			echo '</li>';
		}
		if(!empty($postdata->getSpeakers())){
			echo '<li class="nav-item">';
			echo '<a class="nav-link" id="speakers-tab" data-toggle="tab" href="#speakers" role="tab" aria-controls="speakers" aria-selected="false">' . esc_html__('guests', WP_EVECAL_SLUG ) . '</a>';
			echo '</li>';
		}	
		do_action( 'evecal_after_nav_tabs' );
		echo '</ul>';

		do_action( 'evecal_after_content_tabs' );
		do_action( 'evecal_before_tab_contents' );
		
		echo '<div class="tab-content" id="eventcal-tab-content">';
		echo '<div class="tab-pane fade show active" id="about">';

		do_action( 'evecal_before_about_tab' );
		
		echo '<div class="about-event">';

		do_action( 'evecal_before_title_event_details' );

		$abouttitle = '<h5>'. esc_html__('About The Event', WP_EVECAL_SLUG) . '</h5>';

		$abouttitle = apply_filters( 'evecal_title_event_details', $abouttitle );

        echo $abouttitle;

		do_action( 'evecal_after_title_event_details' );

		do_action( 'evecal_before_event_details' );
        echo $postdata->getEventDesc();
		do_action( 'evecal_after_event_details' );
        
		echo '</div>';

		do_action( 'evecal_before_event_sponsors_title' );

		$sponsortitle = '<h5>' . esc_html__('Sponsors', WP_EVECAL_SLUG) . '</h5>';
		$sponsortitle = apply_filters( 'evecal_sponsors_title', $sponsortitle );
		if (!empty($postdata->getSponsors())) {
			echo $sponsortitle;
		}

		do_action( 'evecal_after_event_sponsors_title' );

		echo '<div class="smart-event-sponsors-container">';

		do_action( 'evecal_before_event_sponsors' );
		echo '<div class="smart-event-sponsors">';
        foreach ($postdata->getSponsors() as $sponsor) {
        	echo '<img src="'. $sponsor .'" />';
        }
		echo '</div>';
		do_action( 'evecal_after_event_sponsors' );

		echo '</div>';

		do_action( 'evecal_after_about_tab' );

		echo '</div>';

		
		echo '<div class="tab-pane fade" id="schedule">';
		do_action( 'evecal_before_schedule_table' );
		echo self::getScheduleTable($postdata);
		do_action( 'evecal_after_schedule_table' );
		echo '</div>';


		do_action( 'evecal_before_speakers_tab' );
		echo '<div class="tab-pane fade" id="speakers">';
		do_action( 'evecal_before_speakers_list' );
		echo self::speakersList($postdata);
		do_action( 'evecal_after_speakers_list' );
		echo '</div>';
		do_action( 'evecal_after_speakers_tab' );

		echo '</div>';

		echo '<script type="text/javascript">';
		echo 'var singlepostid = ' . $post_id;
		echo '</script>';

		do_action( 'evecal_after_tab_contents' );
		
		$response['content'] = ob_get_clean();
		$response['map'] = Helper::getEventMap($postdata->getPostID());
		wp_send_json( $response );
	}
	public static function getScheduleTable($postdata){
		$schedule = array();
		$i = 1;
		foreach ($postdata->getSchedule() as $key => $value) {
			$schedule[] = $value['evecal_schedule_details'];
			$i++;
		}
		$html = '<ul class="nav nav-pills mb-3" id="smart-event-day-schedule">';
		$kcount = (int)count($schedule) + (int)1;
		for ($k=1; $k < $kcount ; $k++) { 
			$active = $k == 1 ? 'active' : '';
			$html .= '<li class="nav-item">';
			$html .= '<a class="nav-link '. $active .'" data-toggle="pill" href="#day-'. $k .'">' . esc_html__('Day ', WP_EVECAL_SLUG) . $k .'</a>';
			$html .= '</li>';
		}
		$html .= '</ul>';
		$html .= '<div class="tab-content" id="pills-tabContent">';
		$j = 1; 
		foreach ($schedule as $key => $value) {
		$active = $j == 1 ? 'active show' : '';
		$html .= '<div class="tab-pane fade '. $active .'" id="day-' . $j . '">';
		$html .= '<ul class="evecal-schedule-list-items">';

		foreach ($value as $key => $value) {
			$html .= '<li>'; 
			$k = 0;
			foreach ($value as $key => $value) {
				$html .= $k<1 ? '<h4>' . $value . '</h4>' : $value;
				$k++;
			}
			$html .= '</li>';
		} 
		$html .= '</ul>';
		$html .= '</div>';
		$j++;
		}
		$html .= '</div>';
		return $html;
	}
	public static function speakersList($postdata){
		$speakers = $postdata->getSpeakers();
		$html = '<div class="ec-row">';
		foreach ($speakers as $key => $value) {
			$html .= '<div class="ec-col-md-3">';
			$html .= '<div class="smart-event-speakers">';
			$html .= '<div class="smart-event-speaker-img">';
			$html .= '<img src="'. wp_get_attachment_url($value['evecal_speaker_img'][0]) .'" class="img-fluid">';
			$html .= '<p class="speaker-session">'. $value['evecal_speaker_session'] .'</p>';
			$html .= '</div>';
			$html .= '<h5 class="speaker-name">'. $value['evecal_speaker_name'] .'</h5>';
			$html .= '<p class="speaker-title">'. $value['evecal_speaker_desig'] .'</p>';
			$html .= '</div>';
			$html .= '</div>';
		}
		$html .= '</div>';
		return $html;
	}
	public static function requestSidebar(){
		if(!check_ajax_referer(WP_EVECAL_SLUG, 'nonce')){
			return '';
		}
		$response = array();
		$post_id = $_POST['id'];
		$postdata = new PostData($post_id);		
		ob_start();

		do_action( 'evecal_before_event_location' );
        if(!empty($postdata->getEventLocation())){
        	echo '<div class="smart-event-grey-featured-box">';
			echo '<h6>' . esc_html__('Location', WP_EVECAL_SLUG) . '</h6>';
			echo '<p>' . $postdata->getEventLocation() . '</p>';
	        echo '</div>';
        }
		do_action( 'evecal_after_event_location' );

		do_action( 'evecal_before_event_organizer' );
        if(!empty($postdata->getOrganizer())){
        	echo '<div class="smart-event-grey-featured-box">';
			echo '<h6>' . esc_html__('Organizer', WP_EVECAL_SLUG) . '</h6>';
			echo '<p>' . $postdata->getOrganizer() . '</p>';
	        echo '</div>';
        }
		do_action( 'evecal_after_event_organizer' );

		do_action( 'evecal_before_event_info_table' );
        echo '<table class="smart-event-sidebar-info-table">';

		do_action( 'evecal_before_event_info_table_row' );
		echo '<tr>';
		echo '<th><h6>' . esc_html__('Time : ', WP_EVECAL_SLUG) . '</h6></th>';
		echo '<td><p>' . Shortcode::timerange($postdata) . '</p></td>';
		echo '</tr>';
		echo '<tr>';
		echo '<th><h6>' . esc_html__('Session :', WP_EVECAL_SLUG ) . '</h6></th>';
		echo '<td><p>' . $postdata->getSessionCount() . esc_html__(' Sessions', WP_EVECAL_SLUG) . '</p></td>';
		echo '</tr>';
		echo '<tr>';
		echo '<th><h6>Speakers : </h6></th>';
		echo '<td><p>' . $postdata->getSpeakersCount() . esc_html__(' Guests', WP_EVECAL_SLUG) . '</p></td>';
		echo '</tr>';
		do_action( 'evecal_after_event_info_table_row' );

		echo '</table>';
		do_action( 'evecal_after_event_info_table' );

		do_action( 'evecal_before_event_share' );
		echo '<div class="smart-event-share-this">';
		echo '<h6>' . esc_html__('Share This Event', WP_EVECAL_SLUG) . '</h6>';
		echo '<div class="ec-row no-gutter">';
		
		do_action( 'evecal_before_event_fb_share' );
		echo '<div class="ec-col-sm-4">';
		echo '<a target="_blank" href="'. $postdata->getShareLinks()['facebook'] .'" class="facebook"><i class="fab fa-facebook-f"></i></a>';
		echo '</div>';
		do_action( 'evecal_after_event_fb_share' );

		do_action( 'evecal_before_event_twitter_share' );
		echo '<div class="ec-col-sm-4">';
		echo '<a target="_blank" href="'. $postdata->getShareLinks()['twitter'] .'" class="twitter"><i class="fab fa-twitter"></i></a>';
		echo '</div>';
		do_action( 'evecal_after_event_twitter_share' );

		do_action( 'evecal_before_event_gplus_share' );
		echo '<div class="ec-col-sm-4">';
		echo '<a target="_blank" href="'. $postdata->getShareLinks()['gplus'] .'" class="google-plus"><i class="fab fa-google-plus"></i></a>';
		echo '</div>';
		do_action( 'evecal_after_event_gplus_share' );

		echo '</div>';
		echo '</div>';
		do_action( 'evecal_after_event_share' );

        $response['sidebar'] = ob_get_clean();
        wp_send_json( $response );
	}

	public static function getInstance(){
		if (empty(self::$instance)) {
			self::$instance = new self();
		}
		return self::$instance;
	}
}