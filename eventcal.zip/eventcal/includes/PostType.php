<?php

namespace WPEVENTCAL\includes;

/**
 * @Add `eventcal` post type
 * @package wordpres
 * @subpackage EventCal
 * @since v1.0
 * 
 * @private var $instance;
 * 
 * 
 */
class PostType
{
	private static $instance;
	public static $gmap_api_link = '<a target="_blank" href="https://developers.google.com/maps/documentation/javascript/get-api-key">Here</a>';
	public static function smartEventPostType(){
		$labels = array(
			'name'               => esc_html__( 'Events',					WP_EVECAL_SLUG ),
			'singular_name'      => esc_html__( 'Event',					WP_EVECAL_SLUG ),
			'menu_name'          => esc_html__( 'EventCal',				WP_EVECAL_SLUG ),
			'name_admin_bar'     => esc_html__( 'EventCal',				WP_EVECAL_SLUG ),
			'add_new'            => esc_html__( 'Add New Event',			WP_EVECAL_SLUG ),
			'add_new_item'       => esc_html__( 'Add New Event',			WP_EVECAL_SLUG ),
			'new_item'           => esc_html__( 'New Event',				WP_EVECAL_SLUG ),
			'edit_item'          => esc_html__( 'Edit Event',				WP_EVECAL_SLUG ),
			'view_item'          => esc_html__( 'View Event',				WP_EVECAL_SLUG ),
			'all_items'          => esc_html__( 'All Events',				WP_EVECAL_SLUG ),
			'search_items'       => esc_html__( 'Search Events',			WP_EVECAL_SLUG ),
			'parent_item_colon'  => esc_html__( 'Parent Events:',			WP_EVECAL_SLUG ),
			'not_found'          => esc_html__( 'No events found.',			WP_EVECAL_SLUG ),
			'not_found_in_trash' => esc_html__( 'No events found in Trash.',WP_EVECAL_SLUG )
		);

		$args = array(
			'labels'             => $labels,
	        'description'        => __( 'Description.',	WP_EVECAL_SLUG ),
			'public'             => true,
			'publicly_queryable' => true,
			'show_ui'            => true,
			'show_in_menu'       => true,
			'query_var'          => true,
			'rewrite'            => array( 'slug' => WP_EVECAL_SLUG ),
			'capability_type'    => 'post',
			'has_archive'        => false,
			'hierarchical'       => false,
			'menu_position'      => null,
			'show_in_rest' 		 => true,
			'rest_base'          => 'eventcal',
			'menu_icon'			 => 'dashicons-calendar-alt',
			'supports'           => array( 'title', 'author', 'thumbnail', 'excerpt', 'comments' )
		);

		register_post_type( WP_EVECAL_SLUG, $args );
	}

	public static function getAllTaxonomies(){
		$taxonomies = array();
		$taxonomy_name = get_option( WP_EVECAL_PREFIX. '_taxonomy_add_text' );
		$taxonomy_hierarchy = get_option( WP_EVECAL_PREFIX. '_taxonomy_hierarchy' );

		$taxonomy = !empty($taxonomy_hierarchy) ? array_combine($taxonomy_name, $taxonomy_hierarchy) : '';
		if (!empty($taxonomy)) {
			foreach ($taxonomy as $key => $value) {
				$taxinsert = array(
					'slug' 			=> strtolower(str_replace(' ', '-', $key)),
					'single_name' 	=> ucwords(esc_attr($key)),
					'plural_name' 	=> ucwords(esc_attr($key)),
					'post_type' 	=> self::getPostType(),
					'rewrite'      	=> array( 'slug' => strtolower(str_replace(' ', '-', $key))),
				);
				array_push($taxonomies, $taxinsert);
			}
		}
		return apply_filters('ec_filters_dropdown', $taxonomies);
	}

	public static function registerTaxonomies() {
		$taxonomies = self::getAllTaxonomies();
		foreach( $taxonomies as $taxonomy ) {
			$labels = array(
				'name' 				=> esc_attr($taxonomy['plural_name']),
				'singular_name' 	=> esc_attr($taxonomy['single_name']),
				'search_items' 		=> esc_html__('Search ' . $taxonomy['plural_name'], WP_EVECAL_SLUG),
				'all_items' 		=> esc_html__('All ' . $taxonomy['plural_name'], WP_EVECAL_SLUG),
				'parent_item' 		=> esc_html__('Parent ' . $taxonomy['single_name'], WP_EVECAL_SLUG),
				'parent_item_colon' => esc_html__('Parent ' . $taxonomy['single_name'] . ':', WP_EVECAL_SLUG),
				'edit_item' 		=> esc_html__('Edit ' . $taxonomy['single_name'], WP_EVECAL_SLUG),
				'update_item' 		=> esc_html__('Update ' . $taxonomy['single_name'], WP_EVECAL_SLUG),
				'add_new_item' 		=> esc_html__('Add New ' . $taxonomy['single_name'], WP_EVECAL_SLUG),
				'new_item_name' 	=> esc_html__('New ' . $taxonomy['single_name'] . ' Name', WP_EVECAL_SLUG),
				'menu_name' 		=> esc_attr($taxonomy['plural_name'])
			);
			
			$rewrite = isset( $taxonomy['rewrite'] ) ? $taxonomy['rewrite'] : array( 'slug' => $taxonomy['slug'] );
			$hierarchical = isset( $taxonomy['hierarchical'] ) ? $taxonomy['hierarchical'] : true;
		
			register_taxonomy( $taxonomy['slug'], $taxonomy['post_type'], array(
				'hierarchical' 	=> $hierarchical,
				'labels' 		=> $labels,
				'show_ui' 		=> true,
				'query_var' 	=> true,
				'rewrite' 		=> $rewrite,
			));
		}
		
	}
	public static function getPostType(){
		return WP_EVECAL_SLUG;
	}
	public static function registerSettings(){
		register_setting( WP_EVECAL_PREFIX . '_general_settings', WP_EVECAL_PREFIX . '_gmap_api' );
		register_setting( WP_EVECAL_PREFIX . '_general_settings', WP_EVECAL_PREFIX . '_modal_open' );
		register_setting( WP_EVECAL_PREFIX . '_general_settings', WP_EVECAL_PREFIX . '_taxonomy_add_text' );
		register_setting( WP_EVECAL_PREFIX . '_general_settings', WP_EVECAL_PREFIX . '_taxonomy_hierarchy' );
	}
	public function addAdminMenuPage(){
		add_submenu_page( 
			'edit.php?post_type=' . self::getPostType(),
			esc_html__('EventCal Settings', WP_EVECAL_SLUG),
			esc_html__('EventCal Settings', WP_EVECAL_SLUG),
			'manage_options',
			str_replace('-', '_', WP_EVECAL_SLUG),
			array( $this, 'generateadminpage' )
		);
	}

	public function generateadminpage(){
		$plugindata = Helper::plugindata();
		$pluginname = $plugindata['Name'];
		?>

			<div class="wrap">
				<h1><?php echo esc_attr( $pluginname ); ?></h1>

				<?php settings_errors(); ?>
				<?php echo self::adminPageNav(); ?>
				<?php echo self::adminPageContents(); ?>
			</div>
		<?php
	}

	public static function adminPageNav(){
		$currenttab = (isset($_REQUEST['tab'])) ? esc_html($_REQUEST['tab']) : 'settings';

		$tabs = array(
            'settings'   => esc_html__( 'Settings', WP_EVECAL_SLUG ),
        );

        $tabs = apply_filters( 'evecal_add_admin_tabs', $tabs );

		$html = '<h2 class="nav-tab-wrapper evecal-nav">';
	        foreach( $tabs as $tab => $name ){
	            $class = ( $tab == $currenttab ) ? 'nav-tab-active' : '';
	            $html .= '<a class="nav-tab ' . $class . '" href="?post_type='. self::getPostType() .'&page='. str_replace('-', '_', WP_EVECAL_SLUG) .'&tab=' . $tab . '">' . $name . '</a>';
	        }
	    $html .= '</h2>';
	    return $html;
	}

	public static function adminPageContents(){
		$currenttab = (isset($_REQUEST['tab'])) ? esc_html($_REQUEST['tab']) : 'settings';

		?>

			<div class="evecal-main-admin-container">
				<?php
					do_action( 'ec_before_admin_settings', $currenttab );
					if($currenttab == 'settings'){
						self::generateSettingsPage();
					}
					do_action( 'ec_after_admin_settings', $currenttab );
				?>
			</div>

		<?php
	}
	public static function generateSettingsPage(){
		$gmap_api = get_option( WP_EVECAL_PREFIX . '_gmap_api' );
		$modal = get_option( WP_EVECAL_PREFIX . '_modal_open' );
		$taxonomy_name = get_option( WP_EVECAL_PREFIX. '_taxonomy_add_text' );
		$taxonomy_hierarchy = get_option( WP_EVECAL_PREFIX. '_taxonomy_hierarchy' );

		$taxonomy = !empty($taxonomy_hierarchy) ? array_combine($taxonomy_name, $taxonomy_hierarchy) : '';
		?>
		<h1><?php esc_html_e('EventCal Settings', WP_EVECAL_SLUG);?></h1>
		<form method="post" action="<?php echo esc_url( admin_url('options.php') ); ?>">
			<?php settings_fields( WP_EVECAL_PREFIX . '_general_settings'); ?>
			<table class="form-table">
				<tr>
					<th>
						<?php esc_html_e( 'Google Maps API Key', WP_EVECAL_SLUG ); ?>
					</th>
					<td>
						<input type="text" name="<?php echo esc_attr( WP_EVECAL_PREFIX . '_gmap_api' ) ?>" id="<?php echo esc_attr( WP_EVECAL_PREFIX . '_gmap_api' ) ?>" value="<?php echo esc_attr( $gmap_api ); ?>">
						<div class="description indicator-hint">
							<?php echo sprintf(__( 'If You Don\'t have an api key you can get from %s', WP_EVECAL_SLUG ), self::$gmap_api_link); ?>
						</div>
					</td>
				</tr>
				<tr>
					<th>
						<?php esc_html_e( 'Open Details In New Window Instead of modal?', WP_EVECAL_SLUG ); ?>
					</th>
					<td>
						<input type="checkbox" name="<?php echo esc_attr( WP_EVECAL_PREFIX . '_modal_open' ) ?>" id="<?php echo esc_attr( WP_EVECAL_PREFIX . '_modal_open' ) ?>" <?php echo esc_attr($modal) !== '' ? ' checked' : '' ?>>
						<label for="<?php echo esc_attr( WP_EVECAL_PREFIX . '_modal_open' ) ?>"><?php esc_html_e('Yes', WP_EVECAL_SLUG); ?></label>
						<div class="description indicator-hint">
							<?php esc_html_e( 'If You wish to open event datails in reloaded window', WP_EVECAL_SLUG ); ?>
						</div>
					</td>
				</tr>
				<tr>
					<th>
						<?php esc_html_e( 'Add Taxonomies/Criteria For Event Filtering', WP_EVECAL_SLUG ); ?>
					</th>
					<td>
						<div class="ec-repeatable-fields">
							<?php
								if(!empty($taxonomy)){
									foreach ($taxonomy as $key => $value) {
										?>
											<div class="ec-repeatable-fieldset">
												<i class="pe-7s-close-circle fieldset-close"></i>
												<div class="ec-repeatable-field">
													<div class="ec-repeatable-field-label">
														<label for="<?php echo esc_attr( WP_EVECAL_PREFIX . '_taxonomy_add_text' ) ?>"><?php esc_html_e('Taxonomy Name', WP_EVECAL_SLUG); ?></label>
													</div>
													<div class="ec-repeatable-field-input">
														<input type="text" name="<?php echo esc_attr( WP_EVECAL_PREFIX . '_taxonomy_add_text[]' ) ?>" value="<?php echo $key; ?>" id="<?php echo esc_attr( WP_EVECAL_PREFIX . '_taxonomy_add_text' ) ?>">
													</div>
												</div>
												<div class="ec-repeatable-field">
													<div class="ec-repeatable-field-label">
					 									<label for="<?php echo esc_attr( WP_EVECAL_PREFIX . '_taxonomy_hierarchy' ); ?>"><?php esc_html_e('Hierarchical?', WP_EVECAL_SLUG); ?></label>
													</div>
													<div class="ec-repeatable-field-input">
														<select name="<?php echo esc_attr( WP_EVECAL_PREFIX . '_taxonomy_hierarchy[]' ); ?>" id="<?php echo esc_attr( WP_EVECAL_PREFIX . '_taxonomy_hierarchy' ); ?>">
															<option value="1" <?php echo $value == true ? 'selected' : ''; ?>><?php esc_html_e('True', WP_EVECAL_SLUG); ?></option>
															<option value="0" <?php echo $value == false ? 'selected' : ''; ?>><?php esc_html_e('false', WP_EVECAL_SLUG); ?></option>
														</select>
													</div>
												</div>
											</div>
										<?php
									}
								}
								else{
									?>
										<div class="ec-repeatable-fieldset">
											<i class="pe-7s-close-circle fieldset-close"></i>
											<div class="ec-repeatable-field">
												<div class="ec-repeatable-field-label">
													<label for="<?php echo esc_attr( WP_EVECAL_PREFIX . '_taxonomy_add_text' ) ?>"><?php esc_html_e('Taxonomy Name', WP_EVECAL_SLUG); ?></label>
												</div>
												<div class="ec-repeatable-field-input">
													<input type="text" name="<?php echo esc_attr( WP_EVECAL_PREFIX . '_taxonomy_add_text[]' ) ?>" value="" id="<?php echo esc_attr( WP_EVECAL_PREFIX . '_taxonomy_add_text' ) ?>">
												</div>
											</div>
											<div class="ec-repeatable-field">
												<div class="ec-repeatable-field-label">
				 									<label for="<?php echo esc_attr( WP_EVECAL_PREFIX . '_taxonomy_hierarchy' ); ?>"><?php esc_html_e('Hierarchical?', WP_EVECAL_SLUG); ?></label>
												</div>
												<div class="ec-repeatable-field-input">
													<select name="<?php echo esc_attr( WP_EVECAL_PREFIX . '_taxonomy_hierarchy[]' ); ?>" id="<?php echo esc_attr( WP_EVECAL_PREFIX . '_taxonomy_hierarchy' ); ?>">
														<option value="1"><?php esc_html_e('True', WP_EVECAL_SLUG); ?></option>
														<option value="0"><?php esc_html_e('false', WP_EVECAL_SLUG); ?></option>
													</select>
												</div>
											</div>
										</div>
									<?php
								}
							?>
							<a href="#" class="ec-repeatable-field-clone"><?php esc_html_e('Add More', WP_EVECAL_SLUG); ?></a>
						</div>
					</td>
				</tr>
			</table>
			<?php submit_button(); ?>
		</form>
		<?php
	} 

	public static function getInstance(){
		if (!isset(self::$instance)) {
			self::$instance = new self();
		}
		return self::$instance;
	}
}