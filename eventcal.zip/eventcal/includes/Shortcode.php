<?php

namespace WPEVENTCAL\includes;

/**
 * @Class Shortcode
 * @package wordpres
 * @subpackage EventCal
 * @since v1.0
 * 
 * @private var $instance;
 * 
 * 
 */
class Shortcode
{
	public static $instance;

	public static function smartEventShortCode($atts){
		$vars = extract(shortcode_atts( 
			array(
	            'columns' => 4,
	            'evecal_monthly_view'	=> false,	            
	            'evecal_weekly_view'	=> false,	            
	            'style'   		=> 1, 
	            'posts_per_page'=> 5,
	            'filters'		=> false,
	            'pagination'	=> true,
	            'sortby'		=> '', //month, week, day
	            'range'			=> 'this', //this, next, next-2
			), $atts ));

		switch ($columns) {
			case 2:
				$columns = 'ec-col-lg-6 ec-col-md-6 ec-col-sm-12 ec-col-xs-12';
				break;

			case 3:
				$columns = 'ec-col-lg-3 ec-col-md-3 ec-col-sm-6 ec-col-xs-12';
				break;

			case 4:
				$columns = 'ec-col-lg-4 ec-col-md-4 ec-col-sm-6 ec-col-xs-12';
				break;

			case 6:
				$columns = 'ec-col-lg-2 ec-col-md-6 ec-col-sm-12 ec-col-xs-12';
				break;

			default:
				$columns = 'ec-col-lg-12 ec-col-md-12 ec-col-sm-12 ec-col-xs-12';
				break;
		}

		if($sortby == 'week'){
			$evecal_weekly_view = true;
		}

		ob_start();
		if($evecal_monthly_view){
			self::sESCMonthlyView();
		}elseif($evecal_weekly_view){
			self::sESCWeeklyView();
		}else{
			$paged = ( get_query_var('paged') ) ? get_query_var('paged') : 1;
		
			$eventargs = array(
				'posts_per_page' 	=> $posts_per_page,
				'post_type'			=> WP_EVECAL_SLUG,
				'paged'				=> $paged,
				'meta_key' 			=> 'evecal_date',
				'orderby'           => 'meta_value',
				'order' 			=> 'ASC',
			);
			if(!empty($sortby) && $sortby === 'month'){
				$eventargs['meta_query'] = 
					array( 
				    	Helper::getEventsBy($sortby, $range)['metadata'],
				    );
				$monthnames = Helper::getEventsBy($sortby, $range)['serialize'];
			}


			$posts = new \WP_Query($eventargs);

			if($filters == 'true' || $filters === true){
				echo Filter::searchConsole();
			}
			echo '<div>';
				echo '<div class="event-contents ec-row" data-style="'. $style .'" data-column="'. $columns .'">';
				if($posts->have_posts()){
					if(!empty($sortby) && $sortby === 'month'){
						foreach ($monthnames as $key => $value) {
							echo '<h4 class="ec-col-md-12">' . $value['month_name'] . '</h4>';
							while ($posts->have_posts()) {
								$posts->the_post();
								$postdata = new PostData(get_the_ID());
									
								$month_code = date('m', strtotime(get_post_meta( get_the_ID(), 'evecal_date', true )));

								if( $month_code == $key ){
									echo self::getStyleControls($style, $columns, $postdata);
								}

							}
							wp_reset_postdata();
						}
					}else{
						while ($posts->have_posts()) {
							$posts->the_post();
							$postdata = new PostData(get_the_ID());
								
							echo self::getStyleControls($style, $columns, $postdata);

						}
						wp_reset_postdata();
					}
				}
				else{
					echo '<div class="no-events text-center">';
					echo '<img src="'. WP_EVECAL_IMAGES_URL .'island.png" />';
					echo '<p>' . esc_html__('No Events Found', WP_EVECAL_SLUG) . '</p>';
					echo '</div>';
				}
				echo '</div>
			</div>';
			if($pagination){
				echo Helper::getPagination($posts->max_num_pages, "", $paged, 'text-center');
			}
		}
		return ob_get_clean();
	}
	public static function ajaxPostsByWeek(){

		$result = array();
		$year = $_POST['year'];
		$week = $_POST['week'];

		$dt = new \DateTime;
		$dt->setISODate($year, $week);
		$week_start = $dt->format('Y-m-d');
		$end_date = $dt->format('d') + 7;
		$week_ends = $dt->format('Y-m-' . $end_date);

		$html = '<thead>';
		    $html .= '<tr>';
				$html .= '<td><a class="whole-week" href="" data-week="'. ($week-1) .'" data-year="'. $year .'">' . esc_html__('Prev Week', WP_EVECAL_SLUG) . '</a></td>';
		do {
		    $html .= "<td class='weekly-date-shuffle' data-date='" . $dt->format('Y-m-d') . "'>" . $dt->format('D') . "<br><span class='weekly-date'>" . $dt->format('d') . "</span><br><p class='weekly-date-month'>". $dt->format('M') ."</p></td>\n";
		    $dt->modify('+1 day');
		} while ($week == $dt->format('W'));
				$html .= '<td><a href="" class="whole-week" data-week="'. ($week+1) .'" data-year="'. $year .'">' . esc_html__('Next Week', WP_EVECAL_SLUG) . '</a></td>';
		    $html .= '</tr>';
		$html .= '</thead>';
		$result['table'] = $html;

		$args = array(
			'posts_per_page'	=> -1,
			'post_type'	=> WP_EVECAL_SLUG,
			'meta_query'	=> array(
				array(
					'key'		=> 'evecal_date',
					'value'		=> array($week_start, $week_ends),
					'type'		=> date,
					'compare'	=> 'BETWEEN',
				),
			),
		);

		$posts = new \WP_Query($args);
		if($posts->have_posts()){
			$events = '<div class="ec-row">';
			while ($posts->have_posts()) {
				$posts->the_post();
				$postdata = new PostData(get_the_ID());
				$events .= '<div class="ec-col-md-6">
						<div class="smart-event-box-4" style="border-top:3px solid '. $postdata->getColor() .'">
                        <div class="ec-row no-gutter">
                            <div class="ec-col-md-3 ec-col-sm-2 ec-col-xs-4">
                                <div class="smart-event-timer align-middle">
                                    <span>'. $postdata->getEventDate()['day'] .'</span>
                                    <span>'. $postdata->getEventDate()['month'] .'</span>
                                </div>
                            </div>
                            <div class="ec-col-md-9 ec-col-sm-10 ec-col-xs-8">
                                <div class="smart-event-main-content">
                                    <div class="smart-event-content">
                                        <h5>'. $postdata->getPostTitle() .'</h5>
                                    </div>
                                    <div class="smart-event-added-content">
                                        <div class="smart-event-location">
                                            <i class="pe-7s-map-marker"></i>
                                            <p>'. $postdata->getEventLocation() .'</p>
                                        </div>
                                        <div class="smart-event-details-link">
                                            <a style="background-color: '. $postdata->getColor() .'" href="" data-id="'. get_the_ID() .'"  class="smart-event-open">Details</a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
	                    </div>
                    </div>';
			}
			wp_reset_postdata();
			$events .= '</div>';
            $result['message'] = $events; 
		}else{
			$noevents = '<div class="no-events text-center">';
			$noevents .= '<img src="'. WP_EVECAL_IMAGES_URL .'island.png" />';
			$noevents .= '<p>' . esc_html__('No Events Found', WP_EVECAL_SLUG) . '</p>';
			$noevents .= '</div>';
			$result['message'] = $noevents; 
		}
		wp_send_json( $result );
	}
	public static function ajaxPostsByWeekDays(){

		$result = array();
		$date = $_POST['date'];

		$args = array(
			'posts_per_page'	=> -1,
			'post_type'	=> WP_EVECAL_SLUG,
			'meta_query'	=> array(
				array(
					'key'		=> 'evecal_date',
					'value'		=> $date,
					'type'		=> date,
				),
			),
		);

		$posts = new \WP_Query($args);
		if($posts->have_posts()){
			$events = '<div class="ec-row">';
			while ($posts->have_posts()) {
				$posts->the_post();
				$postdata = new PostData(get_the_ID());
				$events .= '<div class="ec-col-md-6">
						<div class="smart-event-box-4" style="border-top:3px solid '. $postdata->getColor() .'">
                        <div class="ec-row no-gutter">
                            <div class="ec-col-md-3 ec-col-sm-2 ec-col-xs-4">
                                <div class="smart-event-timer align-middle">
                                    <span>'. $postdata->getEventDate()['day'] .'</span>
                                    <span>'. $postdata->getEventDate()['month'] .'</span>
                                </div>
                            </div>
                            <div class="ec-col-md-9 ec-col-sm-10 ec-col-xs-8">
                                <div class="smart-event-main-content">
                                    <div class="smart-event-content">
                                        <h5>'. $postdata->getPostTitle() .'</h5>
                                    </div>
                                    <div class="smart-event-added-content">
                                        <div class="smart-event-location">
                                            <i class="pe-7s-map-marker"></i>
                                            <p>'. $postdata->getEventLocation() .'</p>
                                        </div>
                                        <div class="smart-event-details-link">
                                            <a style="background-color: '. $postdata->getColor() .'" href="" data-id="'. get_the_ID() .'"  class="smart-event-open">Details</a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
	                    </div>
                    </div>';
			}
			wp_reset_postdata();
			$events .= '</div>';
            $result['message'] = $events; 
		}else{
			$noevents = '<div class="no-events text-center">';
			$noevents .= '<img src="'. WP_EVECAL_IMAGES_URL .'island.png" />';
			$noevents .= '<p>' . esc_html__('No Events Found', WP_EVECAL_SLUG) . '</p>';
			$noevents .= '</div>';
			$result['message'] = $noevents; 
		}
		wp_send_json( $result );
	}
	public static function sESCWeeklyView(){
		$dt = new \DateTime;
		if (isset($_GET['year']) && isset($_GET['week'])) {
		    $dt->setISODate($_GET['year'], $_GET['week']);
		} else {
		    $dt->setISODate($dt->format('o'), $dt->format('W'));
		}
		$year = $dt->format('o');
		$week = $dt->format('W');

		ob_start();

		echo '<div>';
			echo '<div class="ec-row">';
				echo '<div class="ec-col-lg-12 ec-col-md-12 ec-col-sm-12">';
					echo '<table class="evecal-weekly-view">';
						echo '<thead>';
					    echo '<tr>';
							echo '<td><a class="whole-week" href="" data-week="'. ($week-1) .'" data-year="'. $year .'">' . esc_html__('Prev Week', WP_EVECAL_SLUG) . '</a></td>';
					do {
					    echo "<td class='weekly-date-shuffle' data-date='". $dt->format('Y-m-d') ."'>" . $dt->format('D') . "<br><span class='weekly-date'>" . $dt->format('d') . "</span><br><p class='weekly-date-month'>". $dt->format('M') ."</p></td>\n";
					    $dt->modify('+1 day');
					} while ($week == $dt->format('W'));
							echo '<td><a href="" class="whole-week" data-week="'. ($week+1) .'" data-year="'. $year .'">' . esc_html__('Next Week', WP_EVECAL_SLUG) . '</a></td>';
					    echo '</tr>';
						echo '</thead>';
					echo '</table>';
				echo '</div>';
			echo '</div>';
		echo '</div>';

		$args = array(
			'posts_per_page'	=> -1,
			'post_type'		=> WP_EVECAL_SLUG,
			'meta_query'	=> array(
				Helper::getEventsByWeek('this')
			), 
		);
		$weeklyposts = new \WP_Query($args);
		echo '<div class="evecal-weekly-post-container">';
		if($weeklyposts->have_posts()){
		echo '<div class="ec-row">';
			while ($weeklyposts->have_posts()) {
				$weeklyposts->the_post();

				$postdata = new PostData(get_the_ID());
				echo '<div class="ec-col-md-6">
						<div class="smart-event-box-4" style="border-top:3px solid '. $postdata->getColor() .'">
                        <div class="ec-row no-gutter">
                            <div class="ec-col-md-3 ec-col-sm-2 ec-col-xs-4">
                                <div class="smart-event-timer align-middle">
                                    <span>'. $postdata->getEventDate()['day'] .'</span>
                                    <span>'. $postdata->getEventDate()['month'] .'</span>
                                </div>
                            </div>
                            <div class="ec-col-md-9 ec-col-sm-10 ec-col-xs-8">
                                <div class="smart-event-main-content">
                                    <div class="smart-event-content">
                                        <h5>'. $postdata->getPostTitle() .'</h5>
                                    </div>
                                    <div class="smart-event-added-content">
                                        <div class="smart-event-location">
                                            <i class="pe-7s-map-marker"></i>
                                            <p>'. $postdata->getEventLocation() .'</p>
                                        </div>
                                        <div class="smart-event-details-link">';

										$detailslink = '<a style="background-color: '. $postdata->getColor() .'" href="" data-id="'. get_the_ID() .'" class="smart-event-open">' . esc_html__('Details', WP_EVECAL_SLUG) . '</a>';

										$detailslink = apply_filters( 'evecal_tiles_link_filter', $detailslink );

										echo $detailslink;
                                        echo '</div>
                                    </div>
                                </div>
                            </div>
                        </div>
	                    </div>
                    </div>';
			}
			wp_reset_postdata();
		echo '</div>';
		}else{
			echo '<div class="no-events text-center">';
			echo '<img src="'. WP_EVECAL_IMAGES_URL .'island.png" />';
			echo '<p>' . esc_html__('No Events Found', WP_EVECAL_SLUG) . '</p>';
			echo '</div>';
		}
		echo '</div>';
		echo ob_get_clean();
	}
	public static function getEventsByWeek($columns, $postdata){
		ob_start();
		echo'<div class="ec-col-md-'. $columns .'">';
		echo '<div class="smart-event-box-1" style="background:'. self::getColor($postdata) .'">';

		do_action( 'evecal_tiles_before_title' );
		
		echo '<div class="smart-event-title">';
		echo '<h3>' . self::title($postdata) . '</h3>';
		echo '</div>';
		
		do_action( 'evecal_tiles_after_title' );
		do_action( 'evecal_tiles_before_timer' );
		
		echo '<div class="smart-event-timer">';
		echo '<div class="ec-row sm-gutter">';
		echo '<div class="ec-col-md-4">';
		echo '<div class="smart-event-date">';
		echo '<span>'. self::datemonth($postdata)['day'] .'</span>';
		echo '<span>'. self::datemonth($postdata)['month'] .'</span>';
		echo '</div>';
		echo '</div>';
		echo '<div class="ec-col-md-8">';
		echo '<div class="smart-event-timespan">'. self::timerange($postdata) .'</div>';
		echo '<div class="smart-event-speakers">';
		echo '<p>';
		echo esc_html__('Speakers', WP_EVECAL_SLUG);
		foreach ( self::speakers($postdata)[0] as $value) {
			echo '<img src="'. $value .'" alt="speaker"/>';
		}
		if( self::speakers($postdata)[1] > 0 ){
			echo '<span> + ' . self::speakers($postdata)[1] . '</span>';
		}
		echo '</p>';
		echo '</div>';
		echo '</div>';
		echo '</div>';
		echo '</div>';

		do_action( 'evecal_tiles_after_timer' );
		do_action( 'evecal_tiles_before_location' );
		
		echo '<div class="smart-event-location">';
		echo '<p>'. self::location($postdata) .'</p>';
		echo '<i class="pe-7s-map-marker"></i>';
		echo '</div>';
		
		do_action( 'evecal_tiles_after_location' );
		do_action( 'evecal_tiles_before_details_link' );
		
		echo '<div class="smart-event-details-link">';

		$detailslink = '<a href="" data-id="'. get_the_ID() .'" class="smart-event-open">' . esc_html__('Details', WP_EVECAL_SLUG) . '</a>';

		$detailslink = apply_filters( 'evecal_tiles_link_filter', $detailslink );

		echo $detailslink;
		echo '</div>';

		do_action( 'evecal_tiles_after_details_link' );

		echo '</div>';
		echo '</div>';
		return ob_get_clean();
	}
	public static function sESCMonthlyView(){
		/* date settings */
		$month = (int) (isset($_GET['month']) ? $_GET['month'] : date('m'));
		$year = (int)  (isset($_GET['year']) ? $_GET['year'] : date('Y'));

		/* select month control */

		/* "next month" control */
		$next_month_link = '<a class="fright next-month" href="?month='.($month != 12 ? $month + 1 : 1).'&year='.($month != 12 ? $year : $year + 1).'" class="control">Next</a>';

		/* "previous month" control */
		$previous_month_link = '<a class="fright prev-month" href="?month='.($month != 1 ? $month - 1 : 12).'&year='.($month != 1 ? $year : $year - 1).'" class="control">Previous</a>';

		$monthname = '<span class="text-center month-name">'. date('F',mktime(0,0,0,$month,1,$year)) . ' ' . $year .'</span>';
		/* bringing the controls together */
		$controls =  '<div class="calendar-control">' . $next_month_link . $monthname . $previous_month_link . '</div>';
		echo $controls;

		echo self::draw_calendar($month, $year);
	}
	public static function draw_calendar($month,$year){

		/* draw table */
		ob_start();
		echo '<table cellpadding="0" cellspacing="0" class="calendar">';

		$firstday = ( $year . '-' . $month . '-' . '01');
		$lastday = ( $year . '-' . $month . '-' . 't');
		$this_month = array(date($firstday), date($lastday));

		$args = array(
				'posts_per_page' => -1,
				'post_type'	=> WP_EVECAL_SLUG,
				'meta_query'=> array(
					'key' => 'evecal_date',
					'value'=> $this_month,
					'type'	=> 'date',
					'compare'=> 'BETWEEN',
				),
			);
		$posts = new \WP_Query($args);

		$postdateid = array();
		if($posts->have_posts()){
			while ($posts->have_posts()) {
				$posts->the_post();

				$date = get_post_meta( get_the_ID(), 'evecal_date', true);
				if(array_key_exists(date('d', strtotime($date)), $postdateid)){
					array_push( $postdateid[date('d', strtotime($date))]['id'], get_the_ID());
				}else{
					$postdateid[date('d', strtotime($date))] = 
					array( 
						'date' => date('Y-m-d', strtotime($date)), 
						'id' => array(
							get_the_ID()
						),
					);
				}
			}wp_reset_postdata();
		}
		/* table headings */
		$headings = array(
			esc_html__('Sun', WP_EVECAL_SLUG), 
			esc_html__('Mon', WP_EVECAL_SLUG),
			esc_html__('Tues', WP_EVECAL_SLUG), 
			esc_html__('Wed', WP_EVECAL_SLUG), 
			esc_html__('Thu', WP_EVECAL_SLUG), 
			esc_html__('Fri', WP_EVECAL_SLUG), 
			esc_html__('Sat', WP_EVECAL_SLUG)
		);
		echo '<tr class="calendar-ec-row"><td class="calendar-day-head">'.implode('</td><td class="calendar-day-head">',$headings).'</td></tr>';

		/* days and weeks vars now ... */
		$running_day = date('w',mktime(0,0,0,$month,1,$year));
		$days_in_month = date('t',mktime(0,0,0,$month,1,$year));
		$days_in_this_week = 1;
		$day_counter = 0;
		$dates_array = array();

		/* ec-row for week one */
		echo '<tr class="calendar-ec-row">';

		/* print "blank" days until the first of the current week */
		for($x = 0; $x < $running_day; $x++):
			echo '<td class="calendar-day-np"> </td>';
			$days_in_this_week++;
		endfor;

		/* keep going with days.... */
		for($list_day = 1; $list_day <= $days_in_month; $list_day++):
			echo '<td class="calendar-day">';
				/* add in the day number */
				echo '<div class="day-number">'.$list_day.'</div>';

				if(isset($postdateid[ $list_day])){
					if(is_array($postdateid[ $list_day])){
						if(in_array( ( $year . '-' . sprintf( '%02d', $month ) . '-' . sprintf( '%02d', $list_day) ), $postdateid[ ($list_day) ]) ){
							echo '<span class="evecal-event-count">' . count($postdateid[$list_day]['id']) . '</span>';

							echo '<div class="evecal-mc-posts-link-popup">';
							foreach ( $postdateid[$list_day]['id'] as $key => $value) {
								echo '<a href="'. get_the_permalink($value) .'" class="smart-event-open" data-id="'. $value .'">'. get_the_title( $value ) .'</a>';
							}
							echo '</div>';
						}
					}
				}
				echo str_repeat('<p> </p>',2);
				
			echo '</td>';
			if($running_day == 6):
				echo '</tr>';
				if(($day_counter+1) != $days_in_month):
					echo '<tr class="calendar-ec-row">';
				endif;
				$running_day = -1;
				$days_in_this_week = 0;
			endif;
			$days_in_this_week++; $running_day++; $day_counter++;
		endfor;

		/* finish the rest of the days in the week */
		if($days_in_this_week < 8):
			for($x = 1; $x <= (8 - $days_in_this_week); $x++):
				echo '<td class="calendar-day-np"> </td>';
			endfor;
		endif;

		echo '</tr>';
		echo '</table>';
		return ob_get_clean();
	}
	public static function getStyleOne( $columns, $postdata ){
		ob_start();
		echo '<div class="'. $columns .'">
                <div class="smart-event-box-1" style="border-top: 5px solid '. $postdata->getColor() .' ">
                    <div class="smart-event-title">
                        <h3>'. $postdata->getPostTitle() .'</h3>
                    </div>
                    <div class="smart-event-timer">
                        <div class="ec-row sm-gutter">
                            <div class="ec-col-md-4">
                                <div class="smart-event-date">
                                    <span>'. $postdata->getEventDate()['day'] .'<p class="event-ends-date">'. $postdata->getEventEndDate(' -')['day'] .'</p></span>
                                    <span>'. $postdata->getEventDate()['month'] .'</span>
                                </div>
                            </div>
                            <div class="ec-col-md-8">
                                <div class="smart-event-timespan">
                                    '. self::timerange($postdata) .'
                                </div>
                                <div class="smart-event-speakers">
                                    <p>';
                                    for ($i=0; $i < 3; $i++) { 
                                    	if(!empty($postdata->getSpeakersImgs()[$i])){
                                    		echo '<img src="'. $postdata->getSpeakersImgs()[$i] .'" />';
                                		}
                                    }
                                    if( $postdata->showRemainIngSpeakers(3) > 0 ){
                                    	echo '<span> + '. $postdata->showRemainIngSpeakers(3) .'</span>';
                                	}		
                                    echo '</p>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="smart-event-location">
                        <p>'. self::location($postdata) .'</p>
                        <i class="pe-7s-map-marker"></i>
                    </div>
                    <div class="smart-event-details-link">';
					$detailslink = '<a href="" data-id="'. get_the_ID() .'" class="smart-event-open">' . esc_html__('Details', WP_EVECAL_SLUG) . '</a>';

					$detailslink = apply_filters( 'evecal_tiles_link_filter', $detailslink );

					echo $detailslink;
                    echo '</div>
                </div>
            </div>';
        return ob_get_clean();
	}
	public static function getStyleTwo( $columns, $postdata ){
		ob_start();
		echo '<div class="'. $columns .'">
                <div class="smart-event-box-1" style="background:linear-gradient( rgba(255,255,255, 0.95 ), rgba(255,255,255, 0.95) ), url('. $postdata->getEventCover() .') center/cover no-repeat;border-bottom: 4px solid '. $postdata->getColor() .'">
                    <div class="smart-event-title">
                        <h3>'. $postdata->getPostTitle() .'</h3>
                    </div>
                    <div class="smart-event-timer">
                        <div class="ec-row sm-gutter">
                            <div class="ec-col-md-4">
                                <div class="smart-event-date">
                                    <span>'. $postdata->getEventDate()['day'] .'<p class="event-ends-date">'. $postdata->getEventEndDate(' -')['day'] .'</p></span>
                                    <span>'. $postdata->getEventDate()['month'] .'</span>
                                </div>
                            </div>
                            <div class="ec-col-md-8">
                                <div class="smart-event-timespan">
                                    '. self::timerange($postdata) .'
                                </div>
                                <div class="smart-event-speakers">
                                    <p>';
                                    for ($i=0; $i < 3; $i++) { 
                                    	if(!empty($postdata->getSpeakersImgs()[$i])){
                                    		echo '<img src="'. $postdata->getSpeakersImgs()[$i] .'" />';
                                		}
                                    }
                                    if( $postdata->showRemainIngSpeakers(3) > 0 ){
                                    	echo '<span> + '. $postdata->showRemainIngSpeakers(3) .'</span>';
                                	}		
                                    echo '</p>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="smart-event-location">
                        <p>'. self::location($postdata) .'</p>
                        <i class="pe-7s-map-marker"></i>
                    </div>
                    <div class="smart-event-details-link">';
                    $detailslink = '<a href="" data-id="'. get_the_ID() .'" class="smart-event-open">' . esc_html__('Details', WP_EVECAL_SLUG) . '</a>';

					$detailslink = apply_filters( 'evecal_tiles_link_filter', $detailslink );

					echo $detailslink;
                    echo '</div>
                </div>
            </div>';
        return ob_get_clean();
	}
	public static function getStyleThree( $columns, $postdata ){
		ob_start();
		echo '<div class="'. $columns .'">
                <div class="smart-event-box-3" style="background: '. $postdata->getColor() .'">
                    <div class="ec-row no-gutter">
                        <div class="ec-col-md-6">
                            <div class="smart-event-box-img" style="background: url('. $postdata->getEventCover() .');">
                                <div class="smart-event-timer" style="background: '. $postdata->getColor() .'">
                                    <span>'. $postdata->getEventDate()['day'] .'<p class="event-ends-date">'. $postdata->getEventEndDate(' -')['day'] .'</p></span>
                                    <span>'. $postdata->getEventDate()['month'] .'</span>
                                </div>
                                <div class="smart-event-timespan">
                                    '. self::timerange($postdata) .'
                                </div>
                            </div>
                        </div>
                        <div class="ec-col-md-6">
                            <div class="smart-event-main-content">
                                <div class="smart-event-content">
                                    <h4>'. $postdata->getPostTitle() .'</h4>
                                </div>
                                <div class="smart-event-location">
                                    <i class="pe-7s-map-marker"></i>
                                    <p>'. self::location($postdata) .'</p>
                                </div>
                                <div class="smart-event-speakers">
                                    <p>';
                                    if (!empty($postdata->getSpeakers())) {
                                        esc_html_e('Speakers', WP_EVECAL_SLUG);
                                    }
                                    for ($i=0; $i < 3; $i++) { 
                                    	if(!empty($postdata->getSpeakersImgs()[$i])){
                                    		echo '<img src="'. $postdata->getSpeakersImgs()[$i] .'" />';
                                		}
                                    }
                                    if( $postdata->showRemainIngSpeakers(3) > 0 ){
                                    	echo '<span> + '. $postdata->showRemainIngSpeakers(3) .'</span>';
                                	}		
                                    echo '</p>
                                </div>
		                        <div class="smart-event-details-link">';
		                        $detailslink = '<a href="" data-id="'. get_the_ID() .'" class="smart-event-open">' . esc_html__('Details', WP_EVECAL_SLUG) . '</a>';

								$detailslink = apply_filters( 'evecal_tiles_link_filter', $detailslink );

								echo $detailslink;
		                        echo '</div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>';
        return ob_get_clean();
	}
	public static function getStyleFour( $columns, $postdata ){
		ob_start();
		echo '<div class="'. $columns .'">
                <div class="smart-event-box-4">
                    <div class="ec-row no-gutter">
                        <div class="ec-col-md-3 ec-col-sm-2 ec-col-xs-3">
                            <div class="smart-event-timer align-middle" style="border-left: 3px solid '. $postdata->getColor() .'">
                                <span>'. $postdata->getEventDate()['day'] .'<p class="event-ends-date">'. $postdata->getEventEndDate(' -')['day'] .'</p></span>
                                <span>'. $postdata->getEventDate()['month'] .'</span>
                                <div class="smart-event-speakers">
                                    <p>';
                                    	for ($i=0; $i < 3; $i++) { 
                                        	if(!empty($postdata->getSpeakersImgs()[$i])){
                                        		echo '<img src="'. $postdata->getSpeakersImgs()[$i] .'" />';
                                    		}
                                        }
                                        if( $postdata->showRemainIngSpeakers(3) > 0 ){
                                        	echo '<span> + '. $postdata->showRemainIngSpeakers(3) .'</span>';
                                    	}	
                                    echo '</p>
                                </div>
                            </div>
                        </div>
                        <div class="ec-col-md-9 ec-col-sm-10 ec-col-xs-9">
                            <div class="smart-event-main-content">
                                <div class="smart-event-content">
                                    <h5>'. $postdata->getPostTitle() .'</h5>
                                </div>
                                <div class="smart-event-added-content">
                                    <div class="smart-event-location">
                                        <i class="pe-7s-map-marker"></i>
                                        <p>'. self::location($postdata) .'</p>
                                    </div>
			                        <div class="smart-event-details-link">';
			                        $detailslink = '<a href="" data-id="'. get_the_ID() .'" class="smart-event-open">' . esc_html__('Details', WP_EVECAL_SLUG) . '</a>';

									$detailslink = apply_filters( 'evecal_tiles_link_filter', $detailslink );

									echo $detailslink;
			                        echo '</div>
                                </div>
                                <div class="smart-event-timespan">
                                    '. self::timerange($postdata) .'
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>';
        return ob_get_clean();
	}
	public static function getStyleFive( $columns, $postdata ){
		ob_start();
		echo '<div class="'. $columns .'">
                <div class="smart-event-box-4">
                    <div class="ec-row no-gutter">
                        <div class="ec-col-md-3 ec-col-sm-2 ec-col-xs-3">
                            <div class="smart-event-timer align-middle" style="border-top: 3px solid '. $postdata->getColor() .'">
                                <span>'. $postdata->getEventDate()['day'] .'<p class="event-ends-date">'. $postdata->getEventEndDate(' -')['day'] .'</p></span>
                                <span>'. $postdata->getEventDate()['month'] .'</span>
                            </div>
                        </div>
                        <div class="ec-col-md-9 ec-col-sm-10 ec-col-xs-9">
                            <div class="smart-event-main-content" style="border-top: 3px solid '. $postdata->getColor() .'">
                                <div class="smart-event-content">
                                    <h5>'. $postdata->getPostTitle() .'</h5>
                                </div>
                                <div class="smart-event-added-content">
                                    <div class="smart-event-location">
                                        <i class="pe-7s-map-marker"></i>
                                        <p>'. self::location($postdata) .'</p>
                                    </div>
                                    <div class="smart-event-details-link">';

									$detailslink = '<a style="background-color: '. $postdata->getColor() .'" href="" data-id="'. get_the_ID() .'" class="smart-event-open">' . esc_html__('Details', WP_EVECAL_SLUG) . '</a>';

									$detailslink = apply_filters( 'evecal_tiles_link_filter', $detailslink );

									echo $detailslink;

                                    echo '</div>
                                </div>
                                <div class="smart-event-timespan">
                                    '. self::timerange($postdata) .'
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>';
        return ob_get_clean();
	}
	public static function getStyleSix( $columns, $postdata ){
		ob_start();
		echo '<div class="'. $columns .'">
                <div class="smart-event-box-5" style="border-bottom:4px solid '. $postdata->getColor() . '">
                    <div class="smart-event-box-img" style="background: url('. $postdata->getEventCover() .');">
                        <div class="smart-event-timer" style="background:#fff">
                                <span>'. $postdata->getEventDate()['day'] .'<p class="event-ends-date">'. $postdata->getEventEndDate(' -')['day'] .'</p></span>
                                <span>'. $postdata->getEventDate()['month'] .'</span>
                        </div>
                        <div class="smart-event-timespan">
                            '. self::timerange($postdata) .'
                        </div>
                    </div>
                    <div class="smart-event-main-content">
                        <div class="smart-event-content">
                            <h4>' . $postdata->getPostTitle() . '</h4>
                        </div>
                        <div class="smart-event-location">
                            <i class="pe-7s-map-marker"></i>
                            <p>'. self::location($postdata) .'</p>
                        </div>
                        <div class="smart-event-speakers">
                            <p>';
								if (!empty($postdata->getSpeakers())) {
                                    esc_html_e('Speakers', WP_EVECAL_SLUG);
                                }
                                for ($i=0; $i < 3; $i++) { 
                                	if(!empty($postdata->getSpeakersImgs()[$i])){
                                		echo '<img src="'. $postdata->getSpeakersImgs()[$i] .'" />';
                            		}
                                }
                                if( $postdata->showRemainIngSpeakers(3) > 0 ){
                                	echo '<span> + '. $postdata->showRemainIngSpeakers(3) .'</span>';
                            	}
                            echo'</p>
                        </div>
                        <div class="smart-event-details-link">';
                        $detailslink = '<a href="" data-id="'. get_the_ID() .'" class="smart-event-open">' . esc_html__('Details', WP_EVECAL_SLUG) . '</a>';

						$detailslink = apply_filters( 'evecal_tiles_link_filter', $detailslink );

						echo $detailslink;
                        echo '</div>
                    </div>
                </div>
            </div>';
        return ob_get_clean();
	}
	public static function getStyleSeven( $columns, $postdata ){
		ob_start();
		echo '<div class="'. $columns .'">
                <div class="smart-event-box-6" style="background: url('. $postdata->getEventCover() .');">
                    <div class="smart-event-timer">
                        <span>'. $postdata->getEventDate()['day'] .'</span>
                        <span>'. $postdata->getEventDate()['month'] .'</span>
                    </div>
                    <div class="smart-event-main-content" style="background:'. $postdata->getColor() .'">
                        <div class="smart-event-content">
                            <h4>'. $postdata->getPostTitle() .'</h4>
                        </div>
                        <div class="smart-event-location">
                            <i class="pe-7s-map-marker"></i>
                            <p>'. self::location($postdata) .'</p>
                        </div>
                        <div class="smart-event-timespan">
                            '. self::timerange($postdata) .'
                        </div>
                        <div class="smart-event-speakers">
                            <p>';
								if (!empty($postdata->getSpeakers())) {
                                    esc_html_e('Speakers  ', WP_EVECAL_SLUG);
                                }
                                for ($i=0; $i < 3; $i++) { 
                                	if(!empty($postdata->getSpeakersImgs()[$i])){
                                		echo '<img src="'. $postdata->getSpeakersImgs()[$i] .'" />';
                            		}
                                }
                                if( $postdata->showRemainIngSpeakers(3) > 0 ){
                                	echo '<span> + '. $postdata->showRemainIngSpeakers(3) .'</span>';
                            	}
                            echo'</p>
                        </div>
                        <div class="smart-event-details-link">';
                        $detailslink = '<a href="" data-id="'. get_the_ID() .'" class="smart-event-open">' . esc_html__('Details', WP_EVECAL_SLUG) . '</a>';

						$detailslink = apply_filters( 'evecal_tiles_link_filter', $detailslink );

						echo $detailslink;
                        echo '</div>
                    </div>
                </div>
            </div>';
        return ob_get_clean();
	}
	public static function title($data){
		return $data->getPostTitle();
	}
	public static function getStyleControls($style, $columns, $postdata){
		$html = '';
		switch ($style) {
			case '1':
				$html .= self::getStyleOne( $columns, $postdata );
				break;
			case '2':
				$html .= self::getStyleTwo( $columns, $postdata );
				break;
			case '3':
				$html .= self::getStyleThree( $columns, $postdata );
				break;
			case '4':
				$html .= self::getStyleFour( $columns, $postdata );
				break;
			case '5':
				$html .= self::getStyleFive( $columns, $postdata );
				break;
			case '6':
				$html .= self::getStyleSix( $columns, $postdata );
				break;
			case '7':
				$html .= self::getStyleSeven( $columns, $postdata );
				break;
		}
		return $html;
	}

	public static function evecalSCForm(){
		if(!check_ajax_referer(WP_EVECAL_SLUG, 'nonce')){
			return '';
		}
		ob_start();
		echo '
		<div class="evecal-sc-form-container">
			<form method="post" class="evecal-sc-form">
				<table>
					<tr>
						<th>'. esc_html__('Show Monthly Calender View?', WP_EVECAL_SLUG) .'</th>
						<td>
							<input type="checkbox" name="evecal-monthly-view" id="evecal-monthly-view"/>
							<label for="evecal-monthly-view">'. esc_html__('Yes', WP_EVECAL_SLUG) .'</label>
						</td>
					</tr>
					<tr>
						<th>'. esc_html__('Number Of Columns', WP_EVECAL_SLUG) .'</th>
						<td>
							<select name="evecal-sc-columns" id="evecal-sc-columns">
								<option value="2">'. esc_html__('Select Columns', WP_EVECAL_SLUG) .'</option>
								<option value="2">'. esc_html__('Two Columns', WP_EVECAL_SLUG) .'</option>
								<option value="4">'. esc_html__('Three Columns', WP_EVECAL_SLUG) .'</option>
								<option value="3">'. esc_html__('Four Columns', WP_EVECAL_SLUG) .'</option>
								<option value="12">'. esc_html__('Full Width', WP_EVECAL_SLUG) .'</option>
							</select>
						</td>
					</tr>
					<tr>
						<th>'. esc_html__('Select A Style', WP_EVECAL_SLUG) .'</th>
						<td>
							<select name="evecal-sc-style" id="evecal-sc-style">
								<option value="5">'. esc_html__('Select Style', WP_EVECAL_SLUG) .'</option>
								<option value="1">'. esc_html__('Style One', WP_EVECAL_SLUG) .'</option>
								<option value="2">'. esc_html__('Style Two', WP_EVECAL_SLUG) .'</option>
								<option value="3">'. esc_html__('Style Three', WP_EVECAL_SLUG) .'</option>
								<option value="4">'. esc_html__('Style Four', WP_EVECAL_SLUG) .'</option>
								<option value="5">'. esc_html__('Style Five', WP_EVECAL_SLUG) .'</option>
								<option value="6">'. esc_html__('Style Six', WP_EVECAL_SLUG) .'</option>
								<option value="7">'. esc_html__('Style Seven', WP_EVECAL_SLUG) .'</option>
							</select>
						</td>
					</tr>
					<tr>
						<th>'. esc_html__('Arrange Events By-', WP_EVECAL_SLUG) .'</th>
						<td>
							<select name="evecal-sc-arrangeby" id="evecal-sc-arrangeby">
								<option value="">'. esc_html__('Select', WP_EVECAL_SLUG) .'</option>
								<option value="month">'. esc_html__('Month', WP_EVECAL_SLUG) .'</option>
								<option value="week">'. esc_html__('Week', WP_EVECAL_SLUG) .'</option>
							</select>
						</td>
					</tr>
					<tr>
						<th>'. esc_html__('Arrange Events By-', WP_EVECAL_SLUG) .'</th>
						<td>
							<select name="evecal-sc-range" data-dependsOn="evecal-sc-arrangeby=month" id="evecal-sc-range">
								<option value="this">'. esc_html__('Select Range', WP_EVECAL_SLUG) .'</option>
								<option value="next">'. esc_html__('Next Month', WP_EVECAL_SLUG) .'</option>
								<option value="next-2">'. esc_html__('Next Two Month', WP_EVECAL_SLUG) .'</option>
								<option value="next-3">'. esc_html__('Next Three Month', WP_EVECAL_SLUG) .'</option>
								<option value="next-4">'. esc_html__('Next Four Month', WP_EVECAL_SLUG) .'</option>
								<option value="next-5">'. esc_html__('Next Five Month', WP_EVECAL_SLUG) .'</option>
								<option value="next-6">'. esc_html__('Next Six Month', WP_EVECAL_SLUG) .'</option>
								<option value="next-10">'. esc_html__('Next Ten Month', WP_EVECAL_SLUG) .'</option>
								<option value="next-12">'. esc_html__('Next One year', WP_EVECAL_SLUG) .'</option>
							</select>
						</td>
					</tr>
					<tr>
						<th>'. esc_html__('Show Events Per Page', WP_EVECAL_SLUG) .'</th>
						<td>
							<input type="text" name="evecal-sc-ppp" value="6" id="evecal-sc-ppp"/>
							<div class="evecal-sc-desc">'. esc_html__('i.e:5 (-1 For All.)', WP_EVECAL_SLUG) .'</div>
						</td>
					</tr>
					<tr>
						<th>'. esc_html__('Show Filters?', WP_EVECAL_SLUG) .'</th>
						<td>
							<input type="checkbox" name="evecal-sc-filter" id="evecal-sc-filter"/>
							<label for="evecal-sc-filter">'. esc_html__('Yes', WP_EVECAL_SLUG) .'</label>
						</td>
					</tr>
					<tr>
						<th>'. esc_html__('Show Pagination?', WP_EVECAL_SLUG) .'</th>
						<td>
							<input type="checkbox" name="evecal-sc-pagination" id="evecal-sc-pagination"/>
							<label for="evecal-sc-pagination">'. esc_html__('Yes', WP_EVECAL_SLUG) .'</label>
						</td>
					</tr>
					<tr>
						<td>
							<input class="button-primary" type="submit" value="'. esc_html__('Submit', WP_EVECAL_SLUG) .'" id="evecal-sc-submit"/>
						</td>
					</tr>
				</table>
			</form>
		</div>
		';
		$html = ob_get_clean();
		die($html);
	}
	public static function datemonth($data){
		return $data->getEventDate();
	}
	public static function timerange($data){
		$start = $data->getStartTime();
		$end = $data->getEndTime();

		return $start . ' - ' . $end;
	}
	public static function speakers($data){
		$speakers 		= $data->getSpeakers();	
		$show_speakers 	= (int)2;

		$evecal_speaker_images = array();
		$images = array();
		foreach ($speakers as $key => $values) {
			foreach ($values['evecal_speaker_img'] as $value) {
				$evecal_speaker_images[] = wp_get_attachment_image_src( $value, array('64','64'), false );
			}
		}
		foreach ($evecal_speaker_images as $key => $value) {
			$images[] = $value[0];
		}
		$totalspeakers = count($images);
		$extraspeakers = (int)$totalspeakers - $show_speakers;

		return array(array_slice($images, 0, $show_speakers), $extraspeakers);
	}
	public static function location($data){
		return $data->getEventLocation();
	}

	public static function getColor($data){
		return $data->getColor();
	}
	public function detailslink(){}
	public static function getInstance(){
		if (empty(self::$instance)) {
			self::$instance = new self();
		}
		return self::$instance;
	}	
}