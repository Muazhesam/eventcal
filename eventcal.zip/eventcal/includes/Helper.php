<?php

namespace WPEVENTCAL\includes;

/**
 * @Helper Class
 * @package wordpres
 * @subpackage EventCal
 * @since v1.0
 * 
 * @var private $instance;
 * 
 * 
 */
class Helper
{
	private static $instance;
	private static $shortcode_tag = 'eventcal';

	public static function plugindata(){
		return get_plugin_data( WP_EVECAL_ROOT );
	}
	public static function getMapApiKey(){
		return get_option( WP_EVECAL_PREFIX . '_gmap_api' );
	}

	public static function setMapApiKeyLink(){
		return '<a href="' . self::getAdminLink() . '" target="_blank">'. esc_html__( 'Here', WP_EVECAL_SLUG ) .'</a>';
	}
	public static function getAdminLink(){
		return admin_url('edit.php?post_type=' . WP_EVECAL_SLUG . '&page=' . str_replace('-', '_', WP_EVECAL_SLUG));
	}
	public static function getPagination($numpages = '', $pagerange = '', $paged='', $pagination_position='') {

		if (empty($pagerange)) {
	        $pagerange = 2;
	    }

		global $paged;
		if (empty($paged)) {
		    $paged = 1;
		}
		if ($numpages == '') {
		    global $wp_query;
		    $numpages = $wp_query->max_num_pages;
		    if(!$numpages) {
		        $numpages = 1;
		    }
		}

		$pagination_args = array(
		    'base'            => get_pagenum_link(1) . '%_%',
		    'format'          => 'page/%#%',
		    'total'           => $numpages,
		    'current'         => $paged,
		    'show_all'        => False,
		    'end_size'        => 1,
		    'mid_size'        => $pagerange,
		    'prev_next'       => True,
		    'prev_text'       => esc_attr('&laquo;'),
		    'next_text'       => esc_attr('&raquo;'),
		    'type'            => 'list',
		    'add_args'        => false,
		    'add_fragment'    => ''
		);

		$paginate_links = paginate_links($pagination_args);

		if (($paginate_links)) {
		    $output  = "<div class='smart-event-pagination ". $pagination_position ."'>";
		    $output .= $paginate_links;
		    $output .= "</div>";
		    return $output;
		}
	}

	public static function getTinyMCEPlugin( $plugin_array ){
		$plugin_array[self::$shortcode_tag] = WP_EVECAL_JS_URL . 'mce-button.js';
		return $plugin_array;
	}
	public static function getMCEButton( $buttons ){
		array_push($buttons, self::$shortcode_tag);
		return $buttons;
	}
	public static function getEventMap($post_id){
		$postdata = new PostData($post_id);

		$map = get_post_meta( $post_id, 'evecal_map', true );
		$map = explode(',', $map);

		$map[] = $postdata->getPostTitle();
		$map[] = $postdata->getEventDate();
		return $map;
	}
	public static function getEventsByMonth($type){

		$response = array();
		$month = array();

		$today = date('Y-m-d');
		$firstday = 'Y-m-01';
		$lastday = 'Y-m-t';

		$previous_month = array( date( $firstday, strtotime('-1 month')), date( $lastday, strtotime('-1 month')) );

		$next_month = array( date( $firstday, strtotime('1 month')), date( $lastday, strtotime('1 month')) );

		$this_month = array( date( $firstday), date( $lastday) );

		$metadata = 
			array(
		        'key' => 'evecal_date',
		        'value' => $this_month,
		        'type'  => 'date',
		        'compare' => 'BETWEEN'
	        );

		if(!preg_match('~[0-9]~', $type)){
			switch ($type) {
				case 'this':
					$metadata['value'] = $this_month;
					$month[date('m')] = array(
						'month_name' => date('F Y'),
					); 
					break;

				case 'prev':
					$metadata['value'] = $previous_month;
					break;

				case 'next':
					$metadata['value'] = $next_month;
					$month[date('m', strtotime('next month'))] =  array(
						'month_name' => date('F Y', strtotime('next month')),
					); 
					break;
			}
		}else{
			$month_num = explode('-', $type);
			switch ($type) {
				case 'next-' . $month_num[1]:
					$metadata['value'] = array( date( $firstday, strtotime('1 month')), date( $lastday, strtotime( $month_num[1] . ' month')) );
					for ($i = 1; $i <= $month_num[1] ; $i++) { 
						$month[(date('m', strtotime( $i . ' month')))] = array(
							'month_name' => date('F Y', strtotime( $i . ' month')),
							'month_code' => (date('m', strtotime( $i . ' month')))
						); 
					}
					break;
			}
		}
		$response['metadata'] = $metadata;
		$response['serialize'] = $month;
		return $response; 

	}
	public static function getEventsByWeek($type){
		$today = date('w');

		$this_week = array( date( 'Y-m-d', strtotime( '+' . ( 1-$today ) . ' days')), date( 'Y-m-d', strtotime( '+' . ( 7-$today ) . ' days')));

		$next_week = array( date( 'Y-m-d', strtotime( '+' . ( 8-$today ) . ' days')), date( 'Y-m-d', strtotime( '+' . ( 14-$today ) . ' days')));

		$next_2_weeks = array( date( 'Y-m-d', strtotime( '+' . ( 8-$today ) . ' days')), date( 'Y-m-d', strtotime( '+' . ( 21-$today ) . ' days')));

		$metadata = 
			array(
		        'key' => 'evecal_date',
		        'value' => $this_week,
		        'type'  => 'date',
		        'compare' => 'BETWEEN'
	        );

		switch ($type) {
			case 'this':
				$metadata['value'] = $this_week;
				break;

			case 'next':
				$metadata['value'] = $next_week;
				break;

			case 'next-2':
				$metadata['value'] = $next_2_weeks;
				break;
		}
		return $metadata;
	}
	public static function getAllMonths($year = ''){
		$months = array(
				'january' => array(
						'name' => esc_html__('January', WP_EVECAL_SLUG),
						'short' => esc_html__('Jan', WP_EVECAL_SLUG),
						'value' => array(date( $year.'-01-01' ), date( $year.'-01-t' )),
					),
				'february' => array(
						'name' => esc_html__('February', WP_EVECAL_SLUG),
						'short' => esc_html__('Feb', WP_EVECAL_SLUG),
						'value' => array(date( $year.'-02-01' ), date( $year.'-02-t' )),
					),
				'march' => array(
						'name' => esc_html__('March', WP_EVECAL_SLUG),
						'short' => esc_html__('Mar', WP_EVECAL_SLUG),
						'value' => array(date( $year.'-03-01'), date( $year.'-03-t')),
					),
				'april' => array(
						'name' => esc_html__('April', WP_EVECAL_SLUG),
						'short' => esc_html__('Apr', WP_EVECAL_SLUG),
						'value' => array(date( $year.'-04-01'), date( $year.'-04-t')),
					),
				'may' => array(
						'name' => esc_html__('May', WP_EVECAL_SLUG),
						'short' => esc_html__('May', WP_EVECAL_SLUG),
						'value' => array(date( $year.'-05-01'), date( $year.'-05-t')),
					),
				'june' => array(
						'name' => esc_html__('June', WP_EVECAL_SLUG),
						'short' => esc_html__('Jun', WP_EVECAL_SLUG),
						'value' => array(date( $year.'-06-01'), date( $year.'-06-t')),
					),
				'july' => array(
						'name' => esc_html__('July', WP_EVECAL_SLUG),
						'short' => esc_html__('Jul', WP_EVECAL_SLUG),
						'value' => array(date( $year.'-07-01'), date( $year.'-07-t')),
					),
				'august' => array(
						'name' => esc_html__('August', WP_EVECAL_SLUG),
						'short' => esc_html__('Aug', WP_EVECAL_SLUG),
						'value' => array(date( $year.'-08-01'), date( $year.'-08-t')),
					),
				'september' => array(
						'name' => esc_html__('September', WP_EVECAL_SLUG),
						'short' => esc_html__('Sept', WP_EVECAL_SLUG),
						'value' => array(date( $year.'-09-01'), date( $year.'-09-t')),
					),
				'october' => array(
						'name' => esc_html__('October', WP_EVECAL_SLUG),
						'short' => esc_html__('Oct', WP_EVECAL_SLUG),
						'value' => array(date( $year.'-10-01'), date( $year.'-10-t')),
					),
				'november' => array(
						'name' => esc_html__('November', WP_EVECAL_SLUG),
						'short' => esc_html__('Nov', WP_EVECAL_SLUG),
						'value' => array(date( $year.'-11-01'), date( $year.'-11-t')),
					),
				'december' => array(
						'name' => esc_html__('December', WP_EVECAL_SLUG),
						'short' => esc_html__('Dec', WP_EVECAL_SLUG),
						'value' => array(date( $year.'-12-01'), date( $year.'-12-t')),
					),
			);
		return $months;
	}
	public static function getEventsBy($switch, $type){
		switch ($switch) {
			case 'month':
				return self::getEventsByMonth($type);
				break;
			case 'week':
				return self::getEventsByWeek($type);
		}
	}
	public static function getShortCodeTag(){
		return self::$shortcode_tag;
	}
	public static function getInstance(){
		if(!isset(self::$instance)){
			self::$instance = new self();
		}
		return self::$instance;
	}
}