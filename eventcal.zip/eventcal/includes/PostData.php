<?php

namespace WPEVENTCAL\includes;

/**
 * @Includes Postdata
 * @package wordpres
 * @subpackage EventCal
 * @since v1.0
 * 
 * @private var $instance;
 * 
 * 
 */
class PostData
{
	
	private static $instance = null;

	public $post_id = 0;

	public function __construct($post_id = 0){
		if((int)$post_id > 0){
			$this->setId($post_id);
		}
	}

	private function setId($post_id){
		return $this->post_id = $post_id;
	} 
	public function getPostID(){
		return $this->post_id;
	}
	public function getPostLink(){
		return get_the_permalink($this->getPostID());
	}

	public function getPostTitle(){
		return get_the_title( $this->getPostID() );
	}

	public function getEventDesc(){
		return get_post_meta( $this->getPostID(), 'evecal_desc', true );
	}

	public function getEventCover(){
		$attachment_id = get_post_meta( $this->getPostID(), 'evecal_cover_img', false )[0];
		return wp_get_attachment_url( $attachment_id );
	}

	public function getEventLocation(){
		return get_post_meta( $this->getPostID(), 'evecal_location', true );
	}

	public function getEventMap(){
		return get_post_meta( $this->getPostID(), 'evecal_map', false );
	}
	public function getOrganizer(){
		return get_post_meta( $this->getPostID(), 'evecal_organizer', true );
	}
	public function getCountry(){
		return get_post_meta( $this->getPostID(), 'evecal_country', true );
	}

	public function getStartTime(){
		$time = get_post_meta( $this->getPostID(), 'evecal_start_time', true );
		return date('h:iA', strtotime($time));
	}
	public function getEndTime(){
		$time = get_post_meta( $this->getPostID(), 'evecal_end_time', true );
		return date('h:iA', strtotime($time));
	}

	public function getSessionCount(){
		$sessoincount = '';
		$schedule = $this->getSchedule();
		foreach ($schedule as $key => $value) {
			$sessoincount = count($value['evecal_schedule_details']);
		}
		return $sessoincount;
	}

	public function getSpeakersCount(){
		$speakers 		= $this->getSpeakers();	

		$evecal_speaker_images = array();
		$images = array();
		foreach ($speakers as $key => $values) {
			foreach ($values['evecal_speaker_img'] as $value) {
				$evecal_speaker_images[] = wp_get_attachment_image_src( $value, array('64','64'), false );
			}
		}
		foreach ($evecal_speaker_images as $key => $value) {
			$images[] = $value[0];
		}
		return count($images);
	}
	public function showRemainIngSpeakers($show){
		$show_speakers 	= (int)$show;
		$total = $this->getSpeakersCount();

		return ((int)$total- (int)$show_speakers);
	}

	public function getSponsors(){
		$sponsors = get_post_meta( $this->getPostID(), 'evecal_sponsors', false );
		foreach ($sponsors as $sponsor) {
			$sponsors_url[] = wp_get_attachment_url( $sponsor );
		}
		return $sponsors_url;
	}
	
	public function getEventFile(){
		$files = get_post_meta( $this->getPostID(), 'evecal_file', false );
		foreach ($files as $file) {
			$files_url[] = wp_get_attachment_url( $file );
		}
		return $files_url;
	}

	/*
	 ** Fetch Event Date
	 * since EventCal V1.0
	 * uses dateFormat
	 * return Array() // 'day', 'month'
	 * 
	*/
	public function getEventDate(){
		$date = get_post_meta( $this->getPostID(), 'evecal_date', true );
		return self::formatDate($date);
	}
	/*
	 ** Fetch Event Date
	 * since EventCal V1.0
	 * uses dateFormat
	 * return Array() // 'day', 'month'
	 * 
	*/
	public function getEventEndDate($prefix='', $suffix=''){
		$date = get_post_meta( $this->getPostID(), 'evecal_date_ends', true );
		if(!empty($date)){
			return self::formatDate($date, $prefix, $suffix);
		}else{
			return false;
		}
	}

	public function getDayName(){
		$date = get_post_meta( $this->getPostID(), 'evecal_date', true );
		return date('l', strtotime($date));
	}

	public function getColor( $type = 'hex', $opacity = null ){
		$color = get_post_meta( $this->getPostID(), 'evecal_color', true );
		$color = !empty($color) ? $color : '#007bff';
		switch ($type) {
			case 'rgba':
				return self::hex2rgba( $color, $opacity );
				break;
			
			default:
				return $color;
				break;
		}
	}
	public function getSpeakersImgs(){
		$speakers = self::getSpeakers();

		$speakers_img = array();
		foreach ($speakers as $key => $values) {
			foreach ($values['evecal_speaker_img'] as $key => $value) {
				$speakers_img[] = wp_get_attachment_url( $value );
			}
		}

		return $speakers_img;
	}
	public function getSpeakers(){
		$speak = array();
		$speakers_array = get_post_meta( $this->getPostID(), 'evecal_speakers', false );
		foreach ($speakers_array as $speakers) {
			$speakers;
		}
		return $speakers;
	}
	public function getSchedule(){
		$speak = array();
		$schedule_array = get_post_meta( $this->getPostID(), 'evecal_schedule', false );
		foreach ($schedule_array as $schedules) {
			$schedules;
		}
		return $schedules;
	}

	public function getScheduleDays(){
		$totaldays = 0;
		foreach ($this->getSchedule() as $key => $value) {
			$totaldays += (int)count($value['evecal_schedule_day']);
		}
	    return $totaldays;
	}
	public static function formatDate($date, $prefix='', $suffix=''){
		$result = array();
		$result['day'] 		= $prefix . sprintf( '%02d',date('j', strtotime($date))) . $suffix;
		$result['month'] 	= $prefix . date('M', strtotime($date)) . $suffix;
		return $result;
	}

	public static function hex2rgba($color, $opacity = false) {
 
		$default = 'rgb(0,0,0)';
		if(empty($color))
	          return $default; 
	        if ($color[0] == '#' ) {
	        	$color = substr( $color, 1 );
	        }
	 
	        if (strlen($color) == 6) {
	                $hex = array( $color[0] . $color[1], $color[2] . $color[3], $color[4] . $color[5] );
	        } elseif ( strlen( $color ) == 3 ) {
	                $hex = array( $color[0] . $color[0], $color[1] . $color[1], $color[2] . $color[2] );
	        } else {
	                return $default;
	        }
	 
	        $rgb =  array_map('hexdec', $hex);
	 
	        if($opacity){
	        	if(abs($opacity) > 1)
	        		$opacity = 1.0;
	        	$output = 'rgba('.implode(",",$rgb).','.$opacity.')';
	        } else {
	        	$output = 'rgb('.implode(",",$rgb).')';
	        }
	 
	        return $output;
	}
	public function getShareLinks(){
		$permalink = $this->getPostLink();
		$date = $this->getEventDate();
		$sharelinks = array();
		$sharelinks['facebook'] = 'https://www.facebook.com/sharer/sharer.php?u=' . $permalink;
		$sharelinks['twitter'] = 'http://twitter.com/share?text=' . urlencode($this->getPostTitle()) . '&url=' . $permalink;
		$sharelinks['gplus'] = 'https://plus.google.com/share?url=' . $permalink;
		return $sharelinks;
	}

	public static function getInstance(){
		if (empty(self::$instance)) {
			self::$instance = new self();
		}
		return self::$instance;
	}
}