<?php

namespace WPEVENTCAL\includes;

/**
 * @Includes Event Filtering Funciton
 * @package wordpres
 * @subpackage EventCal
 * @since v1.0
 * 
 * @private var $instance;
 * 
 * 
 */
class Filter
{	
	/**
	 * @Instance of class
	 * @package wordpres
	 * @subpackage EventCal
	 * @since v1.0
	 * 
	 * @private var $instance;
	 * 
	 * 
	 */
	private static $instance = null;

	/**
	 * @Get Search Field
	 * @package wordpres
	 * @subpackage EventCal
	 * @since v1.0
	 * 
	 * @public function createFilter()
	 * @args $search
	 * 
	 * @return search
	 * 
	 */
	public static function createFilter($search = true ){
		return self::createSearch();
	}

	/**
	 * @Get Total Search console 
	 * @package wordpres
	 * @subpackage EventCal
	 * @since v1.0
	 * 
	 * @public function searchConsole()
	 * @args void
	 * 
	 * @return Total Search Console
	 * 
	 */
	public static function searchConsole(){
		$taxonomies = PostType::getAllTaxonomies();
		ob_start();
		echo '<div>
			<div class="ec-filter-console">
					<form class="ec-ajax-search">';

					echo self::createMonths();
					echo '<div class="ec-row">';
					foreach ($taxonomies as $taxonomy) {
						echo self::createTaxonomyFilter( PostType::getPostType(), $taxonomy['slug'], $taxonomy['plural_name'] );
					}
					echo '</div>';
				echo '</form>
			</div>
		</div>';
		return ob_get_clean();
	}


	/**
	 * @Get Current Months list with date range
	 * @package wordpres
	 * @subpackage EventCal
	 * @since v1.0
	 * 
	 * @public function createMonths()
	 * @args void
	 * @uses PHP date()
	 * 
	 * @return All Months With Range Values
	 * 
	 */

	public static function createMonths(){
		$today = date('w');
		$currentMonth = date('F');
		$currentYear = date('Y');
		$prevYear = date('Y', strtotime('-1 year'));
		$nextYear = date('Y', strtotime('+1 year'));

		$months = Helper::getAllMonths($currentYear);

		ob_start();

		echo '<div class="ec-row">';
			echo '<div class="ec-col-md-4">
				<div class="ec-search-console">
					<input type="search" id="ec-search-key" name="s" placeholder="'. esc_html__('Search For A Event', WP_EVECAL_SLUG) .'" autocomplete="off">
					<input class="ec-filter-search-submit" type="submit" value="Search"/>
				</div>
			</div>';
			echo '<div class="ec-col-md-2 ec-col-lg-2 ec-col-sm-5 ec-col-xs-5">';
					echo '<div class="ec-filter-month-name">';
						echo date('F, Y');
					echo '</div>';
			echo '</div>
				<div class="ec-col-md-2 ec-col-lg-2 ec-col-sm-7 ec-col-xs-7">
					<div class="ec-row xs-gutter">
						<div class="ec-filter-by-months" id="ec-filter-by-months">
							<a href="" data-year="'. $prevYear .'" class="ec-month-filter-nextprev"><i class="pe-7s-angle-left"></i></a>';
							echo '<select class="ec-filter-months" id="ec_filter_months">';
							foreach ($months as $key => $value) {
								echo '<option value="'. $value['value'][0] .','. $value['value'][1] .'"';
								echo date('m', strtotime($currentMonth)) == date('m', strtotime($value['value'][0])) ? ' selected':'';
								echo '>'. esc_html__($value['name'], WP_EVECAL_SLUG) .'</option>';
							}
							echo '</select>';
							echo '<a href="" data-year="'. $nextYear .'" class="ec-month-filter-nextprev"><i class="pe-7s-angle-right"></i></a>
						</div>				
					</div>
				</div>';
			echo '<div class="ec-col-md-4 ec-col-lg-4 ec-col-sm-12">
				<div class="ec-filter-by-this">';
					echo '<div class="ec-filter-by-months">';
						echo '<input type="radio" class="ec-filter-all" id="ec-filter-by-all" value="2000-01-01, 2099-01-01" /><label for="ec-filter-by-all">'. esc_html__('All', WP_EVECAL_SLUG) .'</label>';
						echo '<input type="radio" class="ec-filter-all" id="ec-filter-by-this-month" value="'. date('Y-m-01') .', '. date('Y-m-t') .'" /><label for="ec-filter-by-this-month">'. esc_html__('This Month', WP_EVECAL_SLUG) .'</label>';
						echo '<input type="radio" class="ec-filter-all" id="ec-filter-by-this-week" value="'. date( 'Y-m-d', strtotime( '+' . ( 1-$today ) . ' days')) .', '. date( 'Y-m-d', strtotime( '+' . ( 7-$today ) . ' days')) .'" /><label for="ec-filter-by-this-week">'. esc_html__('This Week', WP_EVECAL_SLUG) .'</label>';
					echo '</div>';
				echo '</div>';
			echo '</div>';
		echo '</div>';
		return ob_get_clean();
	}


	/**
	 * @Get Current Months list via WP_Ajax and JSON
	 * @package wordpres
	 * @subpackage EventCal
	 * @since v1.0
	 * 
	 * @public function createMonthsByAjax()
	 * @args void
	 * @uses PHP date()
	 * 
	 * @return Pass JSON of the months with values to Ajax Request
	 * 
	 */
	public static function createMonthsByAjax(){

		if(!check_ajax_referer(WP_EVECAL_SLUG, 'nonce')){
			return '';
		}
			
		$currentYear = $_POST['year'];
		$prevYear = $currentYear - 1;
		$nextYear = $currentYear + 1;

		$months = Helper::getAllMonths($currentYear);
		ob_start();
		
		echo '<a href="" data-year="'. $prevYear .'" class="ec-month-filter-nextprev"><i class="pe-7s-angle-left"></i></a>';
			echo '<select class="ec-filter-months" id="ec-filter-by-months">';
				foreach ($months as $key => $value) {
					echo '<option value="'. $value['value'][0] .','. $value['value'][1] .'">'. esc_html__($value['name'], WP_EVECAL_SLUG) .'</option>';
				}
			echo '</select>';		
		echo '<a href="" data-year="'. $nextYear .'" class="ec-month-filter-nextprev"><i class="pe-7s-angle-right"></i></a>';
		$content['dom'] = ob_get_clean();
		$content['year'] = esc_html__('Now: ', WP_EVECAL_SLUG) . $currentYear;
		wp_send_json($content);
	}

	/**
	 * @Get Create Taxonomy Fields if exists
	 * @package wordpres
	 * @subpackage EventCal
	 * @since v1.0
	 * 
	 * @public function createTaxonomyFilter()
	 * @args $post_type - The post type to check from, 
	 *       $taxonomy - The Taxonomy To retrieve From, 
	 *       $name - Term Name
	 * 
	 * @uses getTermsByCPT()
	 * 
	 * @return Taxonomy Filter Form
	 * 
	 */

	public static function createTaxonomyFilter( $post_type, $taxonomy, $name ){
		ob_start();
		$termobjects = self::getTermsByCPT( $post_type, $taxonomy );
		if(!empty($termobjects)){
			echo '<div class="ec-col-md-2 ec-col-lg-2 ec-col-sm-6 ec-col-xs-6">';
			echo '<select class="ec-dropdown-filter" name="sesearchfilter_'. $taxonomy .'" id="ec-search-filter-'. $taxonomy .'">
						<option value="">'. esc_attr(ucwords($name)) .'</option>';
				foreach ($termobjects as $key => $value) {
					echo '<option value="'. $value->term_id .'">'. ucwords($value->name) .'</option>';
				}
			echo '</select>';
			echo '</div>';
		}
		return ob_get_clean();
	}


	/**
	 * @Get Get Terms of a CPT/Taxonomy
	 * @package wordpres
	 * @subpackage EventCal
	 * @since v1.0
	 * 
	 * @public function createTaxonomyFilter()
	 * @args $post_type - The post type to check from, 
	 *       $taxonomy - The Taxonomy To retrieve From
	 * 
	 * @uses WP_Query() Class
	 * 
	 * @return Terms Under an CPT > Taxonomy
	 * 
	 */
	public static function getTermsByCPT( $post_type, $taxonomy ){
		$posts = new \WP_Query( array('post_type' => $post_type) );
		$postids = array();
		if($posts->have_posts()){
			while ($posts->have_posts()) {
				$posts->the_post();
				array_push($postids, get_the_ID());
			}
			wp_reset_postdata();
		}
		$regions = wp_get_object_terms( $postids, $taxonomy );
		return $regions;
	}


	/**
	 * @Get Get posts by ajax on request from filter
	 * @package wordpres
	 * @subpackage EventCal
	 * @since v1.0
	 * 
	 * @public function createTaxonomyFilter()
	 * @args void
	 * 
	 * @uses WP_Query(), PostType() Classes
	 * 
	 * @return Terms Under an CPT > Taxonomy
	 * 
	 */
	public static function ajaxGetPosts(){
		define('DOING_AJAX', true);
		define('SHORTINIT', true);

		$query = array();
		$query_tax = array();
		if(!check_ajax_referer(WP_EVECAL_SLUG, 'nonce')){
			return '';
		}
		$queryString = $_POST['query'];

		wp_parse_str($queryString, $query);
		$style = $_POST['style'];
		$columns = $_POST['columns'];

		$string = isset($query['s']) ? $query['s'] : '';
		$args = array(
				's' => $string,
				'post_status' => 'publish',
				'posts_per_page' => -1,
				'post_type' => PostType::getPostType(),
				'meta_key' 		=> 'evecal_date',
				'orderby'       => 'meta_value',
				'order'			=> 'ASC',
				'tax_query' => array(),
			);

		$taxonomies = PostType::getAllTaxonomies();

		foreach ($taxonomies as $taxonomy) {
			if(array_key_exists( 'sesearchfilter_' . $taxonomy['slug'], $query)){
				$query_tax[$taxonomy['slug']] = $query['sesearchfilter_' . $taxonomy['slug']]; 
			}
		}

		if(!empty($query_tax)){
			if(count($query_tax) > 1){
				$args['tax_query'] = array(
						'relation' => 'AND',
					);
			}
			foreach ($query_tax as $key => $value) {
				$insert = array(
						'taxonomy' => $key,
						'field'  => 'term_id',
						'terms' => $value,
					);
				array_push($args['tax_query'], $insert);
			}
		}

		$date = isset($query['ec-filter-months']) ? $query['ec-filter-months'] : '';
		$newdate = explode(',', $date);

		if(!empty($date)){
			$args['meta_query'] = array(
					array(
				        'key' => 'evecal_date',
				        'value' => $newdate,
				        'type'  => 'date',
				        'compare' => 'BETWEEN'
			        )
				);
		}
		$posts = new \WP_Query($args);
		ob_start();
		if($posts->have_posts()){
			while ($posts->have_posts()) {
				$posts->the_post();
				$postdata = new PostData(get_the_ID());

				echo Shortcode::getStyleControls($style, $columns, $postdata);
			}
			wp_reset_postdata();
		}
		$content['content'] = ob_get_clean();

		if(empty($content['content'])){
			ob_start();
			echo '<div class="ec-col-md-12">
				<div class="no-events text-center">
					<img src="'. WP_EVECAL_IMAGES_URL .'island.png" />
					<p>' . esc_html__('No Events Found', WP_EVECAL_SLUG) . '</p>
				</div>
			</div>';
			$content['content'] = ob_get_clean();
		}
		if(!empty($date)){
			if(date('Y') > date('Y', strtotime($newdate[0]))){
				$content['showdate'] = date('F, Y');
			}else
				$content['showdate'] = date('F, Y', strtotime($newdate[0]));
		}else{
			$content['showdate'] = date('F, Y', strtotime(date('Y-m-d')));
		}
		wp_send_json($content);
	}

	/**
	 * @Instantiate This Class
	 * @package wordpres
	 * @subpackage EventCal
	 * @since v1.0
	 * 
	 * @return self::$instance
	 * 
	 */
	public static function getInstance(){
		if (empty(self::$instance)) {
			self::$instance = new self();
		}
		return self::$instance;
	}
}
