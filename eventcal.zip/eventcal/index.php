<?php
// silence is golden