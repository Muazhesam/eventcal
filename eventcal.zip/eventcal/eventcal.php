<?php
/**
 * Plugin Name: EventCal | WordPress Event Management Plugin
 * Plugin URI: https://smashingdevs.com/eventcal
 * Description: Create Beautiful Event Schedule With Your WordPress Website
 * Version: 1.0
 * Author: iGlyphic
 * Author URI: https://codecanyon.net/user/iglyphic
 * License: Envato
 * Text Domain: eventcal
 *
 */

namespace WPEVENTCAL;

use WPEVENTCAL\includes\MetaBox;
use WPEVENTCAL\includes\PostType;
use WPEVENTCAL\includes\PostData;
use WPEVENTCAL\includes\Helper;
use WPEVENTCAL\includes\Shortcode;
use WPEVENTCAL\includes\SingleData;
use WPEVENTCAL\includes\SinglePopup;
use WPEVENTCAL\includes\Filter;


class SEventLoader
{
	private static $instance = null;

	public static function constants()
	{
		define( 'WP_EVECAL_VERSION' , 	'1.0');
		define( 'WP_EVECAL_PREFIX' , 	'evcal');
		define( 'WP_EVECAL_SLUG' , 	'eventcal');

		// Need to add extra links on plugin activation
		define( 'WP_EVECAL_BASENAME', plugin_basename( __FILE__ ));

		define( 'WP_EVECAL_ROOT', __FILE__);
		define( 'WP_EVECAL_ROOT_DIR', dirname(WP_EVECAL_ROOT));

		define( 'WP_EVECAL_PATH', plugin_dir_path(WP_EVECAL_ROOT));
		define( 'WP_EVECAL_URL', plugin_dir_url(WP_EVECAL_ROOT));

		define( 'WP_EVECAL_JS_URL', 	trailingslashit(WP_EVECAL_URL . 'js'));
		define( 'WP_EVECAL_CSS_URL', 	trailingslashit(WP_EVECAL_URL . 'css'));
		define( 'WP_EVECAL_FONTS_URL', 	trailingslashit(WP_EVECAL_URL . 'fonts'));
		define( 'WP_EVECAL_IMAGES_URL', trailingslashit(WP_EVECAL_URL . 'images'));
	}
	public static function init(){
		self::constants();	

		add_action( 'evecal_tiles_link_filter', array(self::getInstance(), 'bypassModal') );
		add_filter('plugin_action_links_' . WP_EVECAL_BASENAME, array( self::getInstance(), 'addPluginActionLinks'));
		
		add_action( 'init', array(self::getInstance(), 'eventcalLoadTextdomain' ));
		add_action( 'init', array(PostType::getInstance(), 'smartEventPostType'));
		add_action( 'init', array(PostType::getInstance(), 'registerTaxonomies') );

		add_action( 'admin_init', array(PostType::getInstance(), 'registerSettings'));

		add_action( 'admin_menu', array(PostType::getInstance(), 'addAdminMenuPage'));
		add_filter( 'rwmb_meta_boxes', array(MetaBox::getInstance(), 'addEventMeta') );
		add_shortcode( Helper::getShortCodeTag(), array(Shortcode::getInstance(), 'smartEventShortCode') );

		add_action( 'single_template', array(self::getInstance(), 'smartEventSingle'));
		add_action( 'wp_enqueue_scripts', array(self::getInstance(), 'frontendassets'));
		add_action( 'admin_enqueue_scripts', array(self::getInstance(), 'adminassets'));

		// Request Background Image
		add_action( 'wp_ajax_nopriv_requestHeaderImg', array(SinglePopup::getInstance(), 'bgImage') );
		add_action( 'wp_ajax_requestHeaderImg', array(SinglePopup::getInstance(), 'bgImage') );

		// Request Date Time
		add_action( 'wp_ajax_nopriv_requestTitleDate', array(SinglePopup::getInstance(), 'dateTitle') );
		add_action( 'wp_ajax_requestTitleDate', array(SinglePopup::getInstance(), 'dateTitle') );

		// Request Content
		add_action( 'wp_ajax_nopriv_requestContent', array(SinglePopup::getInstance(), 'requestContent') );
		add_action( 'wp_ajax_requestContent', array(SinglePopup::getInstance(), 'requestContent') );

		// Request Sidebar
		add_action( 'wp_ajax_nopriv_requestSidebar', array(SinglePopup::getInstance(), 'requestSidebar') );
		add_action( 'wp_ajax_requestSidebar', array(SinglePopup::getInstance(), 'requestSidebar') );

		// Request weekly posts
		add_action( 'wp_ajax_nopriv_evecal_weekly_posts', array(Shortcode::getInstance(), 'ajaxPostsByWeek') );
		add_action( 'wp_ajax_evecal_weekly_posts', array(Shortcode::getInstance(), 'ajaxPostsByWeek') );

		// Request weekly per day posts
		add_action( 'wp_ajax_nopriv_evecal_weekly_day_posts', array(Shortcode::getInstance(), 'ajaxPostsByWeekDays') );
		add_action( 'wp_ajax_evecal_weekly_day_posts', array(Shortcode::getInstance(), 'ajaxPostsByWeekDays') );

		// Ajax Post Request
		add_action( 'wp_ajax_nopriv_evecal_ajax_search', array(Filter::getInstance(), 'ajaxGetPosts') );
		add_action( 'wp_ajax_evecal_ajax_search', array(Filter::getInstance(), 'ajaxGetPosts') );

		// Ajax Date Request
		add_action( 'wp_ajax_nopriv_ec_ajax_get_months', array(Filter::getInstance(), 'createMonthsByAjax') );
		add_action( 'wp_ajax_ec_ajax_get_months', array(Filter::getInstance(), 'createMonthsByAjax') );

		// Ajax Schortcode Form
		add_action( 'wp_ajax_nopriv_evecalSCForm', array(Shortcode::getInstance(), 'evecalSCForm') );
		add_action( 'wp_ajax_evecalSCForm', array(Shortcode::getInstance(), 'evecalSCForm') );

		add_action( 'get_footer', array(SinglePopup::getInstance(), 'renderSinglePopup') );
		if('true' == get_user_option( 'rich_editing' ))
		{
			add_filter( 'mce_external_plugins', array(Helper::getInstance(), 'getTinyMCEPlugin') );
			add_filter( 'mce_buttons', array(Helper::getInstance(), 'getMCEButton') );
		}
		require_once( 'meta/meta-box.php' );
	}

	public static function frontendassets(){
		wp_enqueue_style( 'eventcal.css', WP_EVECAL_CSS_URL . 'style.css', array(), '1.0', 'all' );
		wp_enqueue_style( 'eventcal.brands.css', WP_EVECAL_CSS_URL . 'fa-brands.min.css', array(), '1.0', 'all' );
		wp_enqueue_style( 'fontawesome.css', 'https://maxcdn.bootstrapcdn.com/font-awesome/4.3.0/css/font-awesome.min.css', array(), '1.0', 'all' );
		wp_enqueue_style( 'bootstrap.css', WP_EVECAL_CSS_URL . 'bootstrap.min.css', array(), '1.0', 'all' );
		wp_enqueue_style( 'pe7stroke.css', WP_EVECAL_FONTS_URL . 'pe-icon-7-stroke.css', array(), '1.0', 'all' );
		wp_enqueue_script( 'eventcal.js', WP_EVECAL_JS_URL . 'script.js', array( 'jquery' ), '1.0', true );
		wp_enqueue_script( 'popper.js', WP_EVECAL_JS_URL . 'popper.min.js', array( 'jquery' ), '1.0', true );
		wp_enqueue_script( 'bootstrap.js', WP_EVECAL_JS_URL . 'bootstrap.min.js', array( 'jquery' ), '1.0', true );
		wp_enqueue_script( 'eventcal.map.js', 'https://maps.googleapis.com/maps/api/js?key=' . Helper::getMapApiKey(), array( 'jquery' ), '1.0', false );
		$localize = array(
			'ajaxurl'	=> admin_url('admin-ajax.php'),
			'imagesurl' => WP_EVECAL_IMAGES_URL,
			'nonce'     => wp_create_nonce(WP_EVECAL_SLUG),
		);
		wp_localize_script( 'eventcal.js', 'eventcaldata', $localize );
	}
	public static function adminassets(){
		wp_enqueue_style( 'eventcal-admin-css', WP_EVECAL_CSS_URL . 'style-admin.css', array(), '1.0', 'all' );
		wp_enqueue_style( 'pe7stroke.css', WP_EVECAL_FONTS_URL . 'pe-icon-7-stroke.css', array(), '1.0', 'all' );
		wp_enqueue_script( 'eventcal-admin-js', WP_EVECAL_JS_URL . 'script-admin.js', array( 'jquery' ), '1.0', true );
		$localize = array(
			'ajaxurl'	=> admin_url('admin-ajax.php'),
			'imagesurl' => WP_EVECAL_IMAGES_URL,
			'nonce'     => wp_create_nonce(WP_EVECAL_SLUG),
		);
		wp_localize_script( 'eventcal-admin-js', 'eventcaladmindata', $localize );
	}
	public static function smartEventSingle($singleevent) {
	    if ('eventcal' == get_post_type(get_queried_object_id())) {
	        $singleevent = dirname(__FILE__) . '/single-eventcal.php';
	    }
	    return $singleevent;
	}
	/**
	 * Load plugin textdomain.
	 *
	 * @since 1.0.0
	 */
	public static function eventcalLoadTextdomain() {
	  load_plugin_textdomain( 'eventcal', false, dirname( plugin_basename( __FILE__ ) ) . '/languages' ); 
	}
	public static function bypassModal($link){
		$postdata = new PostData(get_the_ID());

		if( get_option(WP_EVECAL_PREFIX . '_modal_open') == "on" ){
			$link = '<a href="'. get_the_permalink() .'">' . esc_html__('Details', WP_EVECAL_SLUG) . '</a>';
		}else{
			$link = '<a class="eventcal-open" data-id="'. get_the_ID() .'" href="'. get_the_permalink() .'">' . esc_html__('Details', WP_EVECAL_SLUG) . '</a>';
		}
		return $link;
	}

	public static function addPluginActionLinks( $links = array() ){
		$actionlinkstoadd = array(
			'settings'	=> '<a href="'. 
			add_query_arg(
				array(
					'post_type' => PostType::getPostType(),
					'page'		=> str_replace('-', '_', WP_EVECAL_SLUG),
				),
				admin_url('edit.php')
			) 
			.'" aria-label="">'. esc_html__( 'EventCal Settings', WP_EVECAL_SLUG ) .'</a>',
		);
		return array_merge($actionlinkstoadd, $links);
	}

	public static function getInstance(){
		if (empty(self::$instance)) {
			self::$instance = new self();
		}
		return self::$instance;
	}
}

spl_autoload_register(__NAMESPACE__ . '\\autoload');
add_action( 'plugins_loaded', array(SEventLoader::getInstance(), 'init') );


function autoload($class = '') {
    if (!strstr($class, 'WPEVENTCAL')) {
        return;
    }
    $result = str_replace('WPEVENTCAL\\', '', $class);
    $result = str_replace('\\', '/', $result);
    require $result . '.php';
}
remove_action( 'shutdown', 'wp_ob_end_flush_all', 1 );