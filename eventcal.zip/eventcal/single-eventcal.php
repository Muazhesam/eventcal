<?php

get_header();

$id = get_the_ID();

		ob_start();
		echo '<div class="ec-container">';
		echo '<div class="smart-event-single-total-content evecal-individual-single">
			<div class="smart-event-single-hero">
				<div class="smart-event-single-featured-image" >
					<span class="spinner"></span>
				</div>
				<div class="smart-event-single-title">
				</div>
			</div>
			<div class="smart-event-single-info">
				<span class="spinner-container"></span>
				<div class="smart-event-single-tabbed-info">
				</div>
				<div class="smart-event-single-event-info">
					<h5>Event Information</h5>
					<div class="event-map-container">    
						<div id="event-map">
						</div>
					</div>
					<div class="smart-event-side-info">
					</div>
					</div>
				</div>
			</div>
		</div>
		</div>
		<script type="text/javascript">
			var singlepostid = ' . get_the_ID() .'
		</script>';
		echo ob_get_clean();

get_footer();